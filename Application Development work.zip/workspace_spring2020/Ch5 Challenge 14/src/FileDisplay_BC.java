
/**
 * FileDisplay_BC.java
 * This class has a constructor that is used to set a file name to a private field in the class. The class also has three methods that are used to
 * display the header line in the file, the whole contents in the file, or the file contents with line numbers.
 * @author Benjamin Costello
 *
 */

import java.util.Scanner;
import java.io.*;

public class FileDisplay_BC 
{
	private String name;
	
	/**
	 * A constructor that sets the private name field to a fileName from the driver file.
	 * @param fileName The name of the file being used from the driver
	 */
    public FileDisplay_BC(String fileName) throws IOException
    {
    	this.name = fileName;
    }
    
    /**
     * Displays the header line in the file to the console when printed.
     * @return The header line
     * @throws IOException
     */
    public String displayHead() throws IOException
    {
    	// Create a File object passing it the filename
	    File file = new File(name);
    	
	    // Create a Scanner object passing the File object
    	Scanner inputFile = new Scanner(file);
    	
    	// Get the header line in the file
    	String header = inputFile.nextLine();
    	
    	inputFile.close();
    	
    	return header;
    }
    
    /**
     * Displays the entire contents within the file to the console when called in the Driver.
     * @throws IOException
     */
    public void displayContents() throws IOException
    {
    	// Create a File object passing it the filename
    	File file2 = new File(name);
    	
    	// Create a Scanner object passing the File object
    	Scanner inputFile2 = new Scanner(file2);
    	
    	while (inputFile2.hasNext())
    	{
    		System.out.printf("%10s", inputFile2.nextLine() + "\n");
    	}
    	inputFile2.close();
        
    }
    
    /**
     * Displays the entire contents within the file with line numbers to the console when called in the Driver.
     * @throws IOException
     */
    public void displayWithLineNumbers() throws IOException
    {
    	// Create a File object passing it the filename
    	File file3 = new File(name);
    	
    	// Create a Scanner object passing the File object
    	Scanner inputFile3 = new Scanner(file3);
    	
    	int count = 1;
    	
    	while (inputFile3.hasNext())
    	{
    		System.out.printf("%1s." + "%10s", count, inputFile3.nextLine() + "\n");
    		
    		count++;
    	}
    	inputFile3.close();
    }
}
