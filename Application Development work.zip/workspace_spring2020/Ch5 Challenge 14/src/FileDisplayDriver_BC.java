
/**
 * FileDisplayDriver_BC.java
 * This program displays the file's header line, the entire contents of the file, and the entire contents of the file
 * with line numbers.
 * @author Benjamin Costello
 *
 */

import java.io.*;

public class FileDisplayDriver_BC 
{

	public static void main(String[] args) throws IOException
	{
		String fileName = "StatGrades.txt";
		
		// Create BarChart object
		FileDisplay_BC fd = new FileDisplay_BC(fileName);
		
		// Print the header line to the console
		System.out.println("The Header:\n");
		System.out.print(fd.displayHead() + "\n");
		
	    // Print the whole contents to the console
		System.out.println("\nThe Contents:\n");
		fd.displayContents();
		
		// Print the whole contents with line numbers to the console
		System.out.println("\nThe Contents With Line Numbers:\n");
		fd.displayWithLineNumbers();
	}

}
