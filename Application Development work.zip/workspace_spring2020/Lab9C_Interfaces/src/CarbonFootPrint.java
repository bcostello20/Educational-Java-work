/**
 * The CarbonFootPrint interface imposes a method to calculate carbon foot print on its users.
 * It is implemented into the PassengerFuelCar and CornProduction java files.
 * @author Benjamin Costello
 *
 */

public interface CarbonFootPrint 
{
	public double getCarbonFootPrint();
}
