//Benjamin Costello

public class CarbonFootPrintDriver 
{

	public static void main(String[] args) 
	{
		//Create a PassengerFuelCar that gets 35mpg and has 36000 miles on it.
		PassengerFuelCar pfc = new PassengerFuelCar(35, 36000);
		
		/*Create a CornProduction object representing the production of a farmer that
		 * produces 5000 pounds of corn annually.
		 */
		CornProduction cp = new CornProduction(5000);
		
		System.out.printf("The car produces " + "%.4f" + " metric tons of C02 annually.", pfc.getCarbonFootPrint());
		System.out.printf("\nProducing " + "%.0f" + " pounds of corn yields " + "%.6f" + " metric tons of C02.", cp.getAnnualPoundsProduced(), cp.getCarbonFootPrint());
	}

}
