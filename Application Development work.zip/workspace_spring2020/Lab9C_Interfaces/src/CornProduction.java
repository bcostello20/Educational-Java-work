//Benjamin Costello

public class CornProduction implements CarbonFootPrint
{
	//Member variables
	private double annualPoundsProduced; //Yearly pounds of corn made
	
	public static final double CARBON = 0.000068039; //Carbon dioxide released in the production of 1 pound of corn
	
	public CornProduction(double annualPoundsProduced)
	{
		this.annualPoundsProduced = annualPoundsProduced;
	}
	
	@Override
	public double getCarbonFootPrint()
	{
		return CARBON * annualPoundsProduced;
	}
	
	public double getAnnualPoundsProduced()
	{
		return annualPoundsProduced;
	}
}
