//Benjamin Costello

public class PassengerFuelCar implements CarbonFootPrint
{
	//Member variables
	private double mpg; //Miles per gallon
	private double milesDriven; //The miles driven
	
	public static final double CARBON = 0.000411; //Carbon dioxide for each gallon of gas used

	
	public PassengerFuelCar(double mpg, double milesDriven)
	{
		this.mpg = mpg;
		this.milesDriven = milesDriven;
	}
	
	@Override
	public double getCarbonFootPrint()
	{
		return CARBON * milesDriven / mpg;
	}
	
	public double getMPG()
	{
		return mpg;
	}
}
