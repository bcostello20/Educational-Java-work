
import java.util.Scanner;  // Needed for the Scanner class

/**
 * Benjamin Costello
 * Lab4A
 * PizzaOrder_BC.java
   This program allows the user to order a pizza.
 */

public class PizzaOrder_BC
{
	public static void main (String[] args)
	{
		final double TAX_RATE = .06;  // Sales tax rate
		
		String firstName;             // User's first name
		boolean discount = false;     // Flag for discount
		int inches;                   // Size of the pizza
		char crustType;               // For type of crust
		String crust = "Hand-tossed"; // Name of crust
		double cost = 12.99;          // Cost of the pizza
		double tax;                   // Amount of tax
		String input;                 // User input
		String toppings = "Cheese ";  // List of toppings
		int numberOfToppings = 0;     // Number of toppings

		// Create a Scanner object to read input.
		Scanner keyboard = new Scanner (System.in);
				
		// Prompt user and get first name.
		System.out.println("Welcome to Mike and Diane's Pizza");
		System.out.print("Enter your first name: ");
		firstName = keyboard.nextLine();

		// Determine if user is eligible for discount by
		// having the same first name as one of the owners.
		// ADD LINES HERE FOR TASK #1
		if (firstName.equalsIgnoreCase("Mike") || firstName.equalsIgnoreCase("Diane"))
			discount = true;
		
			
		// Prompt user and get pizza size choice.
		System.out.println("\nPizza Size (inches)   Cost");
		System.out.println("        10            $10.99");
		System.out.println("        12            $12.99");
		System.out.println("        14            $14.99");
		System.out.println("        16            $16.99");
		System.out.println("What size pizza " +
				"would you like?");
		System.out.print("10, 12, 14, or 16 " +
				"(enter the number only): ");
		inches = keyboard.nextInt();

		// Set price and size of pizza ordered.
		// ADD LINES HERE FOR TASK #2
		if (inches == 10)
			cost = 10.99;
		else if (inches == 12)
			cost = 12.99;
		else if (inches == 14)
			cost = 14.99;
		else if (inches == 16)
			cost = 16.99;
		else
		{
			System.out.printf("\nSorry, your input of %d was not one of the choices. A 12-inch pizza will be made.", inches);
			inches = 12;
			cost = 12.99;
		}
		
			
		//Consume the remaining newline character.  
		keyboard.nextLine(); 


		// Prompt user and get crust choice.
		System.out.println("\nWhat type of crust " +
				"do you want? ");
		System.out.print("(H)Hand-tossed, " +
				"(T) Thin-crust, or " +
				"(D) Deep-dish " +
				"(enter H, T, or D): ");

		input = keyboard.nextLine();
		
		// Set user's crust choice on pizza ordered.
		// ADD LINES FOR TASK #3
		crustType = input.charAt(0);
		switch (crustType)
		{
		case 'H':
			crust = "Hand-tossed";
			break;
		case 'h':
			crust = "Hand-tossed";
			break;
		case 'T':
			crust = "Thin-crust";
			break;
		case 't':
			crust = "Thin-crust";
			break;
		case 'D':
			crust = "Deep-dish";
			break;
		case 'd':
			crust = "Deep-dish";
			break;
		default:
			System.out.println("Sorry, your input was not one of the choices. A Hand-tossed crust will be made.");
			crustType = 'H';
			crust = "Hand-tossed";
		}
		

		// Prompt user and get topping choices one at a time.
		System.out.println("\nAll pizzas come with cheese.");
		System.out.println("Additional toppings are " +
				"$1.25 each, choose from:");
		System.out.println("Pepperoni, Sausage, " +
				"Onion, Mushroom");
		
		// If topping is desired,
		// add to topping list and number of toppings
		// TASK #4: Add code for each toppings question below
		System.out.print("Do you want Pepperoni? (Y/N): ");
		input = keyboard.nextLine();
		if (input.charAt(0) == 'Y' || input.charAt(0) == 'y')
		{
			numberOfToppings += 1;
			toppings += "Pepperoni ";
		}

		System.out.print("Do you want Sausage? (Y/N): ");
		input = keyboard.nextLine();
		if (input.charAt(0) == 'Y' || input.charAt(0) == 'y')
		{
			numberOfToppings += 1;
			toppings += "Sausage ";
		}

		System.out.print("Do you want Onion? (Y/N): ");
		input = keyboard.nextLine();
		if (input.charAt(0) == 'Y' || input.charAt(0) == 'y')
		{
			numberOfToppings += 1;
			toppings += "Onion ";
		}

		System.out.print("Do you want Mushroom? (Y/N): ");
		input = keyboard.nextLine();
		if (input.charAt(0) == 'Y' || input.charAt(0) == 'y')
		{
			numberOfToppings += 1;
			toppings += "Mushroom";
		}


		// Add additional toppings cost to cost of pizza.
		// INSERT CODE FOR TASK #5 HERE
		cost += 1.25 * numberOfToppings;
		// Display order confirmation.
		System.out.println();
		System.out.println("Your order is as follows: ");
		System.out.println("\t"+inches + " inch pizza");
		System.out.println("\t"+crust + " crust");
		System.out.println("\t"+toppings);

		// Apply discount if user is eligible.
		// ADD LINES FOR TASK #6 HERE
		if (discount)
		{
			System.out.println("You are eligible for a $2.00 discount.");
			cost -= 2.00;
		}
		
		
		// EDIT PROGRAM FOR TASK #7
		//SO ALL MONEY OUTPUT APPEARS WITH 2 DECIMAL PLACES
		System.out.printf("The cost of your order " +
				"is: $%.2f", cost);

		// Calculate and display tax and total cost.
		tax = cost * TAX_RATE;
		System.out.printf("\nThe tax is: $%.2f", tax);
		System.out.printf("\nThe total due is: $%.2f",
				(tax + cost));

		System.out.print("\nYour order will be ready " +
				"for pickup in 30 minutes.");

		keyboard.close();
	}
}
