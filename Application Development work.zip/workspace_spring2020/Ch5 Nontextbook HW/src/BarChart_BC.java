/**
 * BarChart_BC.java
 * 
 * This program reads in the contents of a Stores.dat file and outputs data from that file to a new file called Results.dat.
 * The Results.dat file creates a bar chart with the store id and a star for each $100 it makes.
 * The program also outputs to the console the input file and output file names, and says "Bar Chart Completed!".
 * 
 * @author Benjamin Costello
 *
 */

import java.util.Scanner;
import java.io.*;

public class BarChart_BC 
{

	public static void main(String[] args) throws IOException
	{
		String fileName = "Results.dat"; // File name
	    
	    // Create a File object passing it the filename
	    File file = new File("Stores.dat");
	    
	    // Create a Scanner object passing the File object
	    Scanner inputFile = new Scanner(file);
	    
	    // Create a FileWriter object using "Results.dat" 
	    FileWriter fw = new FileWriter("Results.dat");
	    
	    // Create a PrintWriter object passing the FileWriter object
	    PrintWriter pw = new PrintWriter(fw);
	    
	    // Loop through the file to gather data
	    while (inputFile.hasNext())
	    {
	    	inputFile.next();
	    	
	    	while (inputFile.hasNextInt() || inputFile.hasNextDouble())
	    	{
	    		int storeID = inputFile.nextInt();
	    		int dailySales = inputFile.nextInt();
	    		
	    		int count = 0;
	    		
	    		pw.print("Store " + storeID + ": ");
	    		
	    		while (count != dailySales/100)
	    		{
	    			pw.print("*");
	    			count += 1;
	    		}
	    		
	    		pw.println("");
	    	}

	    }
	    // Close the output file
	    pw.close();
	    // Close the input file
	    inputFile.close();
	    
	
	    
	    // Print input, output, and Bar Chart Completed to the console
	    System.out.println("Input file: " + file);
	    System.out.println("Output file: " + fileName);
	    System.out.println("Bar Chart Completed!");
	}

}
