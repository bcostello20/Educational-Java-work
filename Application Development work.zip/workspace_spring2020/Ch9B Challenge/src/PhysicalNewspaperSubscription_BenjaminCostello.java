/**
 * The PhysicalNewspaperSubcription_BenjaminCostello class is used to get the
 * subscriber's name and address and checks whether the address is valid (contains at least
 * one number 0-9) or not for a proper subscription rate.
 * @author Benjamin Costello
 *
 */

public class PhysicalNewspaperSubscription_BenjaminCostello extends NewspaperSubscription_BenjaminCostello
{
	//Member variables
	public static final double VALID_RATE = 15.0;
	public static final double INVALID_RATE = 0;
	
	/**
	 * A constructor that takes in a name and address and sends them to the parent class.
	 * @param name The subscriber's name.
	 * @param address The subscriber's address, physical or email.
	 */
	public PhysicalNewspaperSubscription_BenjaminCostello(String name, String address)
	{
		super(name, address);
		setAddress(address);
	}
	
	/**
	 * The setAddress method takes in an address String and loops through
	 * it while looping through a numbers String to compare if any index of both Strings match.
	 * If the indexes match it will add 1 to the counter making the address valid and give a valid rate
	 * of 15. If no index match is found then it will leave counter at 0 making the address invalid and 
	 * give an invalid rate of 0.
	 */
	@Override
	public void setAddress(String address)
	{
		String numbers = "0123456789";
		int counter = 0;
		
		for (int i = 0; i < address.length(); i++)
		{
			for (int j = 0; j < numbers.length(); j++)
			{
				if (address.charAt(i) == numbers.charAt(j))
					counter += 1;
			}
		}
		if (counter == 0)
		{
			System.out.println("ERROR: Address does not contain at least one digit (0-9).");
			rate = INVALID_RATE;
			address = "";
		}
		else
			rate = VALID_RATE;
		
	}
}
