/**
 * The SubscriptionDriver_BenjaminCostello class creates an array of 6
 * NewspaperSubscription_BenjaminCostello objects. It then adds to each element of the array
 * in order 3 physical subscriptions followed by 3 online subscriptions. Each set of
 * subscriptions has at least one issue. It then loops through the 6 elements of
 * the array and displays the indexes of subscription information to the console.
 * @author Benjamin Costello
 *
 */

public class SubscriptionDriver_BenjaminCostello 
{
	//Member variables
	public static final int SIZE = 6; //Size of the array
	
	public static void main(String[] args) 
	{
		//Declare an array of 6 NewspaperSubscription objects
		NewspaperSubscription_BenjaminCostello[] nps = new NewspaperSubscription_BenjaminCostello[SIZE];
		
		//Three PhysicalNewspaperSubscription and three OnlineNewspaperSubscription declared
		nps[0] = new PhysicalNewspaperSubscription_BenjaminCostello("Garry Ortiz", "7310 Del Monte Drive");
		nps[1] = new PhysicalNewspaperSubscription_BenjaminCostello("Joe Smith", "Franklin Avenue");
		nps[2] = new PhysicalNewspaperSubscription_BenjaminCostello("Rosemary Dawson", "9332 Shadow Brook Drive");
		nps[3] = new OnlineNewspaperSubscription_BenjaminCostello("Stuart Hanson", "sh@yahoo.com");
		nps[4] = new OnlineNewspaperSubscription_BenjaminCostello("Jeanette Mcdaniel", "jm@gmail.com");
		nps[5] = new OnlineNewspaperSubscription_BenjaminCostello("Tracey Walton", "twhotmail.com");
		
		//Loop over the array and display the objects' state data via the toString method
		for (int i = 0; i < nps.length; i++)
		{
			System.out.println(nps[i]);
		}
	}

}
