/**
 * The OnlineNewspaperSubcription_BenjaminCostello class is used to get the
 * subscriber's name and address and checks whether the address is valid (contains
 * an @ symbol) or not for a proper subscription rate.
 * @author Benjamin Costello
 *
 */

public class OnlineNewspaperSubscription_BenjaminCostello extends NewspaperSubscription_BenjaminCostello
{
	//Member variables
	public static final double VALID_RATE = 9.0;
	public static final double INVALID_RATE = 0;
	public static final char AT_SIGN = '@';
	
	/**
	 * A constructor that takes in a name and address and sends them to the parent class.
	 * @param name The subscriber's name.
	 * @param address The subscriber's address, physical or email.
	 */
	public OnlineNewspaperSubscription_BenjaminCostello(String name, String address)
	{
		super(name, address);
		setAddress(address);
	}
	
	/**
	 * The setAddress method takes in an address String and loops through it checking
	 * to see if any index of it contains the @ symbol. If it does not contain an
	 * @ symbol then it will leave counter at 0 making the address invalid and a rate of 0.
	 * If the address contains an @ symbol it will make the address valid and a rate of 9.
	 */
	@Override
	public void setAddress(String address)
	{
		int counter = 0;
		
		for (int i = 0; i < address.length(); i++)
		{
			
			if (address.charAt(i) == AT_SIGN)
			{
				counter += 1;
			}
		}
			if (counter == 0)
			{
				System.out.println("ERROR: Email address does not contain an at sign (@).");
				rate = INVALID_RATE;
				address = "";
			}
			else
				rate = VALID_RATE;
	}
}
