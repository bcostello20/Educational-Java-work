/**
 * The NewspaperSubscription_BenjaminCostello class stores a user's name and physical address or email address
 * and displays to the console their information along with their subscription rate.
 * @author Benjamin Costello
 *
 */

public abstract class NewspaperSubscription_BenjaminCostello
{
	//Member variables
	protected String subscriberName;
	protected String subscriberAddress;
	protected double rate;
	
	/**
	 * A constructor to set the default values of the String fields.
	 * @param subName The user's subscription name.
	 * @param subAddress The user's subscription address, physical or email.
	 */
	public NewspaperSubscription_BenjaminCostello(String subName, String subAddress)
	{
		this.subscriberName = subName;
		this.subscriberAddress = subAddress;
	}
	
	/**
	 * The getSubscriberName method gets the subscriber's name.
	 * @return The subscriber's name.
	 */
	public String getSubscriberName()
	{
		return subscriberName;
	}
	
	/**
	 * The setSubscriberName method takes in a name String and sets it as the subscriber's name.
	 * @param name The subscriber's name.
	 */
	public void setSubscriberName(String name)
	{
		subscriberName = name;
	}
	
	/**
	 * The getAddress method gets the subscriber's address, physical or email.
	 * @return The subscriber's address, physical or email.
	 */
	public String getAddress()
	{
		return subscriberAddress;
	}
	
	/**
	 * The getRate method gets the subscriber's subscription rate based on physical or email address.
	 * @return The subscriber's subscription rate.
	 */
	public double getRate()
	{
		return rate;
	}
	
	/**
	 * The setAddress abstract method sets up an empty method ready to be used in
	 * the subclasses where it is called in their respective constructors to set the 
	 * subscriber's address here in the parent class.
	 * @param address The subscriber's address, physical or email.
	 */
	public abstract void setAddress(String address);
	
	/**
	 * The toString method returns a String representation of the object
	 * displaying the subscriber's information to the console.
	 */
	public String toString()
	{
		String s = "Name: " + subscriberName + "\nAddress: " + subscriberAddress + "\nRate: " + rate + "\n";
		return s;
	}
}
