/**
 * 
 * @author Benjamin Costello
 *
 */

public class StatStudent {

	private String id;
	private	double quizAvg;
	private	double hwAvg;
	private	double stpAvg;
	private	double examAvg;
	private	double finalExam;
	
	public StatStudent(String studentId, double quizzes, double hw, double stps, double exams, double finalScore)
	{
			id = studentId;
			quizAvg = quizzes;
			hwAvg = hw;
			stpAvg = stps;
			examAvg = exams;
			finalExam = finalScore;
	}

	public String getId() {
		return id;
	}

	public double computeFinalGrade()
	{
		return quizAvg * 0.125 + hwAvg * 0.1 + stpAvg * 0.125 + examAvg * 0.5 + finalExam * 0.15;
	}
	
}
