/**
 * @author Benjamin Costello
 */

import java.util.Scanner;
import java.io.*;

public class GradeCalculator 
{

	public static void main(String[] args) throws IOException
	{
		Scanner keyboard = new Scanner(System.in);
		String fileName;	// The user input file name
		
		 // Prompt the user and read in the file name
	      System.out.println("This program calculates " +
	                         "student final grades on a file " +
	                         "containing student stats");
	      System.out.print("Enter the input file name:  ");
	      fileName = keyboard.nextLine();

	      keyboard.close();
	      
	      // Create a File object passing it the filename
	      File myFile = new File(fileName);
	      
	      // Create a Scanner object passing the File object
	      Scanner inputFile = new Scanner(myFile);
	      
	      // Read in the first line of the file
	      String firstLine;	// The first line in the file (the header)
	      
	      firstLine = inputFile.nextLine();
	      
	      // Loop over the rest of the information in the file gathering student data
	      String data;
	      while (inputFile.hasNext())
	      {
	    	 data = inputFile.next();
	    	 StatStudent Student = new StatStudent(data, Double.parseDouble(data), Double.parseDouble(data), Double.parseDouble(data), Double.parseDouble(data), Double.parseDouble(data));
	    	 System.out.println("ID: " + Student.getId() + ", " + "Grade: " + Student.computeFinalGrade());
	      }
	      inputFile.close();
	}

}
