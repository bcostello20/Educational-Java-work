
public class Driver 
{

	public static void main(String[] args) 
	{
		Rectangle r1 = new Rectangle(1, 2, Color.RED);
		
		Rectangle r2 = new Rectangle(1, 2, Color.RED);
		
		System.out.println(r1.getColor() == r2.getColor());
		
		System.out.println(Color.GREEN.ordinal());
		
		System.gc();
	}

}
