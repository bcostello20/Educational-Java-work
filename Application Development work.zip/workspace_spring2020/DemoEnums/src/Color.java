
public enum Color 
{
    RED("red"), GREEN("green"), BLUE("blue");
	
	private String prettyString;
	
	private Color(String s)
	{
		prettyString = s;
	}
	
	public String toString()
	{
		return prettyString;
	}
}
