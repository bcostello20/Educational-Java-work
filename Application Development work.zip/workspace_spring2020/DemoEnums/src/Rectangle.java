
public class Rectangle 
{
	private double length;
	private double width;
	private Color color;

	//public enum Color {RED, BLUE, GREEN};
	
	public Rectangle(double l, double w, Color c)
	{
		length = l;
		width = w;
		color = c;
	}

	public Color getColor()
	{
		return color;
	}
	
	public double getLength()
	{
		return this.length;
	}
	
	public double getWidth()
	{
		return this.width;
	}

	public boolean equals (Rectangle other)
	{
		return this.length == other.length && 
				this.width == other.width;
	}

	public double calculateArea()
	{
		return length * width;
	}
	
	public double calculatePerimeter()
	{
		return 2 * (length + width);
	}
	
	public void finalize()
	{
		System.out.println("DEATH SUITS ME");
	}

}
