
/**
 * The TeamLeader class stores data about a team leader including their monthly bonus,
 * required training hours, and training hours attended.
 * @author Benjamin Costello
 *
 */

public class TeamLeader extends ProductionWorker
{
	// Member fields
	private double monthlyBonus; // Monthly bonus in addition to an hourly rate
	private double requiredTrainingHours; // Attend a minimum number of hours of training per year
	private double trainingHoursAttended; // Number of hours this team leader has attended
	
	/**
	 * A constructor that calls the superclass constructor and sets the member fields.
	 * @param n The employee's name.
	 * @param num The employee's number.
	 * @param date The employee's hire date.
	 * @param sh The employee's shift.
	 * @param rate The employee's hourly rate.
	 * @param mb The employee's monthly bonus.
	 * @param rth The employee's required training hours.
	 * @param tha The employee's training hours attended.
	 */
	public TeamLeader(String n, String num, String date, int sh, double rate, double mb, double rth, double tha)
	{
		super();
	    this.setName(n);
	    this.setEmployeeNumber(num);
	    this.setHireDate(date);
	    this.setPayRate(rate);
		this.monthlyBonus = mb;
		this.requiredTrainingHours = rth;
		this.trainingHoursAttended = tha;
	}
	
	/**
	 * Default constructor that calls the superclass constructor and sets the member fields to default values of 0.
	 */
	public TeamLeader()
	{
		super();
		this.monthlyBonus = 0.0;
		this.requiredTrainingHours = 0.0;
		this.trainingHoursAttended = 0.0;
	}
	
	/**
	 * The setMonthlyBonus method sets the employee's monthly bonus.
	 * @param b The employee's monthly bonus.
	 */
	public void setMonthlyBonus(double b)
	{
		this.monthlyBonus = b;
	}
	
	/**
	 * The setRequiredTrainingHours method sets the employee's required training hours.
	 * @param p The employee's required training hours.
	 */
	public void setRequiredTrainingHours(double p)
	{
		this.requiredTrainingHours = p;
	}
	
	/**
	 * The setTrainingHoursAttended method sets the employee's training hours attended.
	 * @param t The employee's training hours attended.
	 */
	public void setTrainingHoursAttended(double t)
	{
		this.trainingHoursAttended = t;
	}
	
	/**
	 * The getMonthlyBonus method gets the employee's monthly bonus.
	 * @return The employee's monthly bonus.
	 */
	public double getMonthlyBonus()
	{
		return monthlyBonus;
	}
	
	/**
	 * The getRequiredTrainingHours method gets the employee's required training hours.
	 * @return The employee's required training hours.
	 */
	public double getRequiredTrainingHours()
	{
		return requiredTrainingHours;
	}
	
	/**
	 * The getTrainingHoursAttended method gets the employee's training hours attended.
	 * @return The employee's training hours attended.
	 */
	public double getTrainingHoursAttended()
	{
		return trainingHoursAttended;
	}
	
	@Override
	/**
	 * toString method
	 * @return A reference to a String representation of
              the object.
	 */
	public String toString()
	{
		String str = super.toString();
		
		str+= "\nMonthly Bonus: $" + String.format("%.2f", monthlyBonus) + "\nRequired Training Hours: " + String.format("%.1f", requiredTrainingHours)
		+ "\nTraining Hours Attended: " + String.format("%.1f", trainingHoursAttended);
		
		return str;
	}
}
