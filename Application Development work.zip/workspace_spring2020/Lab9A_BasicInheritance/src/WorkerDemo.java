
/**
   This program demonstrates a solution to 
   the Employee Classes but initializing
   ProductionWorkers and Employees.

   @author Benjamin Costello

*/

public class WorkerDemo extends ProductionWorker
{
   public static void main(String[] args)
   {
	   
	  /*
	   * Task #3 Include Code to create ProductionWorkers
	   * so as to get the following output.
	   * DO NOT HARD CODE �0� and �1� FOR THE DAY/NIGHT SHIFTS.  
	   * USE THE CONSTANTS YOU PROVIDED!!! 
	   * 
	   *    Here's the first production worker.
	   *	Name: John Smith
	   *	Employee Number: 123-A
	   *	Hire Date: 11-15-2005
	   *	Shift: Day
	   *	Hourly Pay Rate: $16.50
	   *	
	   *	Here's the second production worker.
	   *	Name: Joan Jones
	   *	Employee Number: 222-L
	   *	Hire Date: 12-12-2005
	   *	Shift: Night
	   *	Hourly Pay Rate: $18.50
	   *
	   * 
	   * */
	   
	   // Using non-default constructor
	   ProductionWorker pWorker = new ProductionWorker("John Smith", "123-A", "11-15-2005", DAY_SHIFT, 16.50);
	   
	   // Using default constructor
	   ProductionWorker pWorker2 = new ProductionWorker();
	   pWorker2.setName("Joan Jones");
	   pWorker2.setEmployeeNumber("222-L");
	   pWorker2.setHireDate("12-12-2005");
	   pWorker2.setShifts(ProductionWorker.NIGHT_SHIFT);
	   pWorker2.setPayRate(18.50);
	   
	   System.out.println("Here's the first production worker.\n" + pWorker);
	   System.out.println();
	   System.out.println("Here's the second production worker.\n" + pWorker2);
	   System.out.println();
	   
      /*TASK 4A:  Use the non-default constructor to create a TeamLeader t whose information is below.
            Here's the first team leader.
			Name: Janet Jackson
			Employee Number: 456-B
			Hire Date: 01-17-2015
			Shift: Day
			Hourly Pay Rate: $21.50
			Monthly Bonus: $500.00
			Required Training Hours: 5.0
			Training Hours Attended: 2.5
       */
      
	   TeamLeader t = new TeamLeader("Janet Jackson", "465-B", "01-17-2015", DAY_SHIFT, 21.50, 500.00, 5.0, 2.5);
	   System.out.println("Here's the first team leader.\n" + t);
	   System.out.println();
      
      /*TASK 4B:  Use the default constructor and set methods to create a TeamLeader t2 whose information is below.
		Name: Michael Jackson
		Employee Number: 333-J
		Hire Date: 12-12-2012
		Shift: Night
		Hourly Pay Rate: $18.50
		Monthly Bonus: $600.00
		Required Training Hours: 7.0
		Training Hours Attended: 3.5

 */

	   TeamLeader t2 = new TeamLeader();
	   t2.setName("Michael Jackson");
	   t2.setEmployeeNumber("333-J");
	   t2.setHireDate("12-12-2012");
	   t2.setShifts(NIGHT_SHIFT);
	   t2.setPayRate(22.50);
	   t2.setMonthlyBonus(600.00);
	   t2.setRequiredTrainingHours(7.0);
	   t2.setTrainingHoursAttended(3.5);
	   System.out.println("Here's the second team leader.\n" + t2);
   }
}
