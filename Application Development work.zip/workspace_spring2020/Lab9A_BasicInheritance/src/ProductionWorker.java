
/**
 * The ProductionWorker class stores data about a production worker including their shift, hourly pay rate,
 * and what shift they are on.
 * @author Benjamin Costello
 *
 */

public class ProductionWorker extends Employee
{
	// Member fields
	private int shift; // Either being a 0 for night shift or 1 for day shift
	private double payRate; // A Production Worker's hourly pay rate
	public final static int DAY_SHIFT = 1;
	public final static int NIGHT_SHIFT = 0;
	
	/**
	 * A constructor which calls the super constructor.
	 * @param n The employee's name.
	 * @param num The employee's number.
	 * @param date The employee's hire date.
	 * @param sh The employee's shift.
	 * @param rate The employee's hourly pay rate.
	 */
	public ProductionWorker(String n, String num, String date, int sh, double rate)
	{
		super();
		this.setName(n);
		this.setEmployeeNumber(num);
		this.setHireDate(date);
		this.shift = sh;
		this.payRate = rate;
	}
	
	/**
	 * Default constructor that calls the Employee default constructor and sets shift to day shift and pay rate to 0.0.
	 */
	public ProductionWorker()
	{
		super();
		this.shift = DAY_SHIFT;
		this.payRate = 0.0;
	}
	
	/**
	 * The setShifts method sets the employee's shift.
	 * @param s The employee's shift.
	 */
	public void setShifts(int s)
	{
		this.shift = s;
	}
	
	/**
	 * The setPayRate method sets the employee's hourly pay rate.
	 * @param p The employee's hourly pay rate.
	 */
	public void setPayRate(double p)
	{
		this.payRate = p;
	}
	
	/**
	 * The getShift method gets the employee's shift.
	 * @return The employee's shift.
	 */
	public int getShift()
	{
		return shift;
	}
	
	/**
	 * The getPayRate method gets the employee's hourly pay rate.
	 * @return The employee's hourly pay rate.
	 */
	public double getPayRate()
	{
		return payRate;
	}
	
	@Override
	/**
	 * toString method
	 * @return A reference to a String representation of
              the object.
	 */
	public String toString()
	{
		String str = super.toString();
		
		String dayOrNight = "";
		
		if (shift == 1)
			dayOrNight = "Day";
		else
			dayOrNight = "Night";
		
		str+= "\nShift: " + dayOrNight + "\nHourly Pay Rate: $" + String.format("%.2f", payRate);
		
		return str;
	}
}
