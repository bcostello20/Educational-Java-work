/**
 * The AbstractDriver_BC class is the main program which creates an array of 4 objects.
 * It then creates the shape objects for each element slot in the array.
 * Lastly, it loops through the array displaying each shapes' toString method.
 * @author Benjamin Costello
 *
 */

public class AbstractDriver_BC 
{

	public static void main(String[] args) 
	{
		//Variables
		final int SIZE = 4; //Size of object array
		
		// An array of objects
		Shape[] shapes = new Shape[SIZE];
		
		//Create Circle object with radius of 10 meters
		shapes[0] = new Circle(10, Units.METERS);
		
		//Create Triangle object with sides of 3, 4, and 5 centimeters
		shapes[1] = new Triangle(3, 4, 5, Units.CENTIMETERS);
		
		//Create Rectangle object with length 2 and width 8 kilometers
		shapes[2] = new Rectangle(2, 8, Units.KILOMETERS);
		
		//Create Square object with side length 12 millimeters
		shapes[3] = new Square(12, Units.MILLIMETERS);
		
		//Loop through the Shape array and print out the correct information
		for (int i = 0; i < shapes.length; i++)
		{
			System.out.println(shapes[i] + "\n");
		}
	}

}
