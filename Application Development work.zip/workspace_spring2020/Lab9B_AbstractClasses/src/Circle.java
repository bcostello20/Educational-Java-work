/**
 * The Circle class gets and stores information in order to create a Circle shape.
 * @author Benjamin Costello
 *
 */

public class Circle extends Shape
{
	//Member fields
	private double radius; //Radius of a circle
	
	/**
	 * A constructor that takes in a radius and units and sets their values.
	 * @param radius The circle's radius.
	 * @param units The circle's unit abbreviation.
	 */
	public Circle(double radius, Units units)
	{
		super(units);
		this.radius = radius;
	}
	
	/**
	 * The getRadius method gets the circle's radius.
	 * @return The circle's radius.
	 */
	public double getRadius()
	{
		return radius;
	}
	
	/**
	 * The setRadius method sets the circle's radius.
	 * @param r The circle's radius.
	 */
	public void setRadius(double r)
	{
		radius = r;
	}
	
	/**
	 * The getArea method gets the circle's area.
	 * @return The circle's area.
	 */
	@Override
	public double getArea()
	{
		double area = PI * Math.pow(radius, 2);
		return area;
	}
	
	/**
	 * The getPerimeter method gets the circle's perimeter.
	 * @return The circle's perimeter.
	 */
	@Override
	public double getPerimeter()
	{
		double perimeter = 2 * PI * radius;
		return perimeter;
	}
	
	/**
	 * The toString method returns a String representation of the Circle object.
	 * @return The String version of the object.
	 */
	@Override
	public String toString()
	{
		boolean circleIsObject = false;
		boolean circleIsShape = false;
		//boolean circleIsRectangle = false;
		
		if (Circle.this instanceof Object)
			circleIsObject = true;
		
		if (Circle.this instanceof Shape)
			circleIsShape = true;
		
		//if (Circle.this instanceof Rectangle)
			//circleIsRectangle = true;
		
		String s = "Circle Info:\n" + "Radius: " + String.format("%.3f", radius) + " " + units.getAbbreviation() + "\nPerimeter: " + String.format("%.3f", getPerimeter()) + " " 
	+ units.getAbbreviation() + "\nArea: " + String.format("%.3f", getArea()) + " " + units.getAbbreviation() + "-squared" + "\nIs of type Object? " + circleIsObject
	+ "\nIs of type Shape? " + circleIsShape;
		
		return s;
	}
}
