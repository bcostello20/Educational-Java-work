/**
 * The Rectangle class gets and stores information for a Rectangle object.
 * @author Benjamin Costello
 *
 */

public class Rectangle extends Shape
{
	//Member variables
	protected double length; //Length of the rectangle
	protected double width; //Width of the rectangle
	
	/**
	 * A constructor that takes in a length, width, and units and sets their values.
	 * @param length The rectangle's length.
	 * @param width The rectangle's width.
	 * @param units The rectangle's unit abbreviation.
	 */
	public Rectangle(double length, double width, Units units)
	{
		super(units);
		this.length = length;
		this.width = width;
	}
	
	/**
	 * The getLength method gets the rectangle's length.
	 * @return The rectangle's length.
	 */
	public double getLength()
	{
		return length;
	}
	
	/**
	 * The setLength method sets the rectangle's length.
	 * @param l The rectangle's length.
	 */
	public void setLength(double l)
	{
		length = l;
	}
	
	/**
	 * The getWidth method gets the rectangle's width.
	 * @return The rectangle's width.
	 */
	public double getWidth()
	{
		return width;
	}
	
	/**
	 * The setWidth method sets the rectangle's width.
	 * @param w The rectangle's width.
	 */
	public void setWidth(double w)
	{
		width = w;
	}
	
	/**
	 * The getArea method gets the rectangle's area.
	 * @return The rectangle's area.
	 */
	@Override
	public double getArea()
	{
		return length * width;
	}
	
	/**
	 * The getPerimeter method gets the rectangle's perimeter.
	 * @return The rectangle's perimeter.
	 */
	@Override
	public double getPerimeter()
	{
		return 2 * (length + width);
	}
	
	/**
	 * The toString method returns a String representation of the Rectangle object.
	 * @return The String version of the object.
	 */
	@Override
	public String toString()
	{
		boolean rectangleIsObject = false;
		boolean rectangleIsShape = false;
		
		if (Rectangle.this instanceof Object)
			rectangleIsObject = true;
		
		if (Rectangle.this instanceof Shape)
			rectangleIsShape = true;
		
		String s = "Rectangle Info:\n" + "Length: " + String.format("%.3f", getLength()) + " " + units.getAbbreviation() + "\n" + "Width: " + String.format("%.3f", getWidth()) 
		+ " " + units.getAbbreviation() + "\nPerimeter: " + String.format("%.3f", getPerimeter()) + " " + units.getAbbreviation() + "\nArea: " + String.format("%.3f", getArea())
		+ " " + units.getAbbreviation() + "-squared" + "\nIs of type Object? " + rectangleIsObject + "\nIs of type Shape? " + rectangleIsShape;
		return s;
	}
}
