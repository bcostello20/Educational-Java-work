/**
 * The Shape class takes in and stores information to create a Shape object in the Driver file.
 * @author Benjamin Costello
 *
 */

public abstract class Shape 
{
	//Member variables
	protected Units units;
	public static final double PI = 3.1415926;
	
	/**
	 * A constructor that takes in a units enum.
	 * @param units The units abbreviation enum.
	 */
	public Shape(Units units)
	{
		this.units = units;
	}
	
	/**
	 * The getUnits method gets the units to be used for the enum.
	 * @return The units for the enum.
	 */
	public Units getUnits()
	{
		return units;
	}
	
	/**
	 * The setUnits method sets the units for the enum.
	 * @param u The units for the enum.
	 */
	public void setUnits(Units u)
	{
		this.units = u;
	}
	
	/**
	 * The abstract getArea method gets an area for a shape object.
	 * @return The area as a double.
	 */
	public abstract double getArea();
	
	/**
	 * The abstract getPerimeter method gets a perimeter for a shape object.
	 * @return The perimeter as a double.
	 */
	public abstract double getPerimeter();
}
