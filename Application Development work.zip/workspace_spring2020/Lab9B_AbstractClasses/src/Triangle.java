/**
 * The Triangle class gets and stores information for a Triangle object.
 * @author Benjamin Costello
 *
 */

public class Triangle extends Shape
{
	//Member variables
	private double side1; //Side 1 of the triangle
	private double side2; //Side 2 of the triangle
	private double side3; //Side 3 of the triangle
	
	/**
	 * A constructor that takes in three sides, and units and sets their values.
	 * @param side1 The triangle's first side.
	 * @param side2 The triangle's second side.
	 * @param side3 The triangle's third side.
	 * @param units The triangle's unit abbreviation.
	 */
	public Triangle(double side1, double side2, double side3, Units units)
	{
		super(units);
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}
	
	/**
	 * The getArea method gets the triangle's area.
	 * @return The triangle's area.
	 */
	@Override
	public double getArea()
	{
		return side1 * side2 / 2.0;
	}
	
	/**
	 * The getPerimeter method gets the triangle's perimeter.
	 * @return The triangle's perimeter.
	 */
	@Override
	public double getPerimeter()
	{
		return side1 + side2 + side3;
	}
	
	/**
	 * The toString method returns a String representation of the Triangle object.
	 * @return The String version of the object.
	 */
	@Override
	public String toString()
	{
		boolean triangleIsObject = false;
		boolean triangleIsShape = false;
		
		if (Triangle.this instanceof Object)
			triangleIsObject = true;
		
		if (Triangle.this instanceof Shape)
			triangleIsShape = true;
		
		String s = "Triangle Info:\n" + "Side 1: " + String.format("%.3f", side1) + " " + units.getAbbreviation() + "\nSide 2: " + String.format("%.3f", side2) + " " + units.getAbbreviation()
		+ "\nSide 3: " + String.format("%.3f", side3) + " " + units.getAbbreviation() + "\nPerimeter: " + String.format("%.3f", getPerimeter()) + " " + units.getAbbreviation()
		+ "\nArea: " + String.format("%.3f", getArea()) + " " + units.getAbbreviation() + "-squared" + "\nIs of type Object? " + triangleIsObject + "\nIs of type Shape? " + triangleIsShape;
		return s;
	}
}
