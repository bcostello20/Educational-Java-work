/**
 * The Square class gets and stores information for a Square object.
 * @author Benjamin Costello
 *
 */

public class Square extends Rectangle
{
	/**
	 * A constructor that takes in a side length, and units and sets their values. 
	 * @param sideLength The square's side length.
	 * @param units The square's unit abbreviation.
	 */
	public Square(double sideLength, Units units)
	{
		super(sideLength, sideLength, units);
	}
	
	/**
	 * The toString method returns a String representation of the Square object.
	 * @return The String version of the object.
	 */
	@Override
	public String toString()
	{
		boolean squareIsObject = false;
		boolean squareIsShape = false;
		
		if (Square.this instanceof Object)
			squareIsObject = true;
		
		if (Square.this instanceof Shape)
			squareIsShape = true;
		
		String s = "Square Info:\n" + "Each Side: " + String.format("%.3f", this.getLength()) + " " + units.getAbbreviation()
		+ "\nPerimeter: " + String.format("%.3f", this.getPerimeter()) + " " + units.getAbbreviation()
		+ "\nArea: " + String.format("%.3f", this.getArea()) + " " + units.getAbbreviation() + "-squared" + "\nIs of type Object? " + squareIsObject
		+ "\nIs of type Shape? " + squareIsShape;
		return s;
	}
}
