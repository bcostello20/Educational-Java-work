/**
 * A enum of shape unit abbreviations.
 * @author Benjamin Costello
 *
 */

public enum Units {

		MILLIMETERS("mm"), CENTIMETERS("cm"), METERS("m"), KILOMETERS("km");
		
		private final String abbreviation;
		
		Units(String a)
		{
			abbreviation = a;
		}
		
		public String getAbbreviation()
		{
			return abbreviation;
		}
}
