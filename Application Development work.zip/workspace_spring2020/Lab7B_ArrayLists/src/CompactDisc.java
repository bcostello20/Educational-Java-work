
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
   This program creates a list of songs for a CD
   by reading from a file.
   
   It also creates an ArrayList of songs for a mixedCD
   by getting user input.
   
   @author Benjamin Costello
*/


public class CompactDisc
{
   public static void main(String[] args)throws IOException
   {
	  
	  
      File file = new File("Classics.txt");  //File we'll read from
      Scanner inputFile = new Scanner(file); //Scanner to read in File
      String title;
      String artist;

      // ADD LINES FOR TASK #1 HERE
      // Declare an array of Song objects, called cd,
      // with a size of 6.  
      
      //_______________________________
      Song[] cd = new Song[6];
            

      // TASK #2:  Use a for loop to read in the 
      // contents of Classics.txt which we are assuming has
      // exactly 6 songs in it. Check out the Ch 5B notes if 
      // you forget how to read in from a file.
      // Fill the array by creating a new song with
      // the current title and artist and storing it in the
      // appropriate position in the cd array.
      // Uncomment out the code below to help you.
   
      for (int i = 0; i < cd.length; i++)
      {
         title = inputFile.nextLine();
         artist = inputFile.nextLine();         

    	  		//!!!!!!!some code goes here!!!!!!! 
         cd[i] = new Song(title, artist);
      }

      
      System.out.println("**********************");
      System.out.println("Contents of Classics:");
      System.out.println("**********************");

      // TASK #3:
      // Print the contents of the cd array to the console.
      // Since you created a nice toString for the Song class
      // be sure to use it (either explicitly/implicitly)!
      // Uncomment out the code below to help you.
      
      for (int i = 0; i < cd.length; i++)
      {
	  		//!!!!!!!some code goes here!!!!!!!
    	  System.out.println(cd[i].toString());
      }
      
      inputFile.close(); //We're done with the file.
     
      
      //Now we will get user input to create a mixed cd.
      System.out.println("\n**************************************");
      System.out.println("Now create your favorite mixed cd!");
      System.out.println("**************************************\n");
      
      
      Scanner kb = new Scanner(System.in);  //Keyboard scanner    
      String continueStr;  //Whether the user wants to continue or not

    
      // TASK #4:
      // Declare an ArrayList of Song objects, called mixedCD.
      // You do not know (nor need to know) the size of mixedCD.
      // Then use the do-while loop below to populate the contents
      // of mixedCD.

      //__________________________________________________________
      ArrayList<Song> mixedCD = new ArrayList<Song>();

      do
      {    	  
    	  //Ask the user for a song and title for the mixedCD
    	  System.out.print("Enter Song Title: ");
    	  title = kb.nextLine();

    	  System.out.print("Enter Artist: ");
    	  artist = kb.nextLine();
    	  
    	  //!!!!!!!some code goes here!!!!!!!
    	  Song temp;
    	  temp = new Song(title, artist);
    	  mixedCD.add(temp);
    	  
    	  System.out.print("Add another? (yes/no) ");
    	  continueStr = kb.nextLine();

      } while (continueStr.equalsIgnoreCase("yes"));
      
      
      //Now let's print the mixedCD contents out
      System.out.println("\n**************************************");
      System.out.println("Contents of your favorite mixed CD: ");
      System.out.println("**************************************");
      
      // TASK #5:
      // Uncomment out the for loop below.  Use it to
      // print the contents of the mixedCD arrayList to the console 
      // Need to know how many elements they entered?  
      // You don't have to track it -  Just use
      // the size() method on the mixedCD ArrayList!!!
      
      for (int i = 0; i < mixedCD.size(); i++)
      {  
	  		//!!!!!!!some code goes here!!!!!!! 
    	  System.out.println(mixedCD.get(i));
      }
      
      
      kb.close(); //close the Scanner

   }
}
