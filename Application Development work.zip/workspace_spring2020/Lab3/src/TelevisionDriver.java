/**
 * Chapter 3 Lab - Classes and Objects
 * Benjamin Costello
 * TelevisionDriver.java
 * This program works like a TV. It allows the user to use the keyboard like they would a TV remote to turn a TV ON and OFF, and set its volume, and channel.
 */

import java.util.Scanner;

public class TelevisionDriver {

	  public static void main(String[] args)
	   {
	      // Create a Scanner object to read from the keyboard
	      Scanner keyboard = new Scanner (System.in);

	      // Declare variables
	      int station;         // The user's channel choice

	      // Declare and instantiate a television object
	      Television bigScreen = new Television("Toshiba", 55);
	      Television portable = new Television("Sharp", 19);

	      // Turn the power on
	      bigScreen.power();
	      portable.power();

	      // Display the state of the television
	      System.out.println("A " +
	                         bigScreen.getScreenSize() +
	                         " inch " +
	                         bigScreen.getManufacturer() +
	                         " has been turned on.");

	      // Prompt the user for input and store into station
	      System.out.print("What channel do you want? ");
	      station = keyboard.nextInt();

	      // Change the channel on the television
	      bigScreen.setChannel(station);

	      // Increase the volume of the television
	      bigScreen.increaseVolume();

	      //**************************************************************
	      // TASK 4: Display the the current channel and volume of the television
	      System.out.println("Channel: " + station +  " Volume: " + bigScreen.getVolume());
	      System.out.println("Too loud! Lowering the volume.");

	      //Decrease the volume of the tv by 6 units here
	      bigScreen.decreaseVolume();
	      bigScreen.decreaseVolume();
	      bigScreen.decreaseVolume();
	      bigScreen.decreaseVolume();
	      bigScreen.decreaseVolume();
	      bigScreen.decreaseVolume();

	      //Display the the current channel and volume of the television
	      System.out.println("Channel: " + station + " Volume: " + bigScreen.getVolume());
	      System.out.println();   // For a blank line

	      //**************************************************************
	      // Do TASK #5  Here
	      
	      // Display the state of the television
	      System.out.println("A " +
	                         portable.getScreenSize() +
	                         " inch " +
	                         portable.getManufacturer() +
	                         " has been turned on.");

	      // Prompt the user for input and store into station
	      System.out.print("What channel do you want? ");
	      station = keyboard.nextInt();

	      // Change the channel on the television
	      portable.setChannel(station);
	      
	      // Set choice to a default value of nothing so the while loop runs at least once
	      char choice = ' ';
     while (choice != 'N' || choice != 'n')
	    {
	      // Ask the user if they would like the volume louder, softer, or neither
	      System.out.println("Would you like the volume louder (L), softer (S), or neither (N)?: ");
	      choice = keyboard.next().charAt(0);
	          
	      	  // Increases the TV volume
	    	  if (choice == 'L' || choice == 'l')
	    	  {
	    		  portable.increaseVolume();
	    		  portable.increaseVolume();
	    		  System.out.println("Increasing the volume.");
	    		  System.out.println("Channel: " + station +  " Volume: " + portable.getVolume());
	    	  }
	    	  // Decreases the TV volume
	    	  if (choice == 'S' || choice == 's')
	    	  {
	    		  portable.decreaseVolume();
	    		  portable.decreaseVolume();
	    		  System.out.println("Decreasing the volume.");
	    		  System.out.println("Channel: " + station +  " Volume: " + portable.getVolume());
	    	  }
	    	  // Keeps the current TV volume
	    	  if (choice == 'N' || choice == 'n')
	    	  {
	    		  System.out.println("Just right!");
	    		  System.out.println("Final Settings: " + "Channel: " + station +  " Volume: " + portable.getVolume());
	    		  break;
	    	  }
	      }
	      
	      // Close keyboard
	      keyboard.close();
	   }
}