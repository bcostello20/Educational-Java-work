/**
 * A television class
 * @author Ben
 *
 */

public class Television {

	// Declare member variables
			private String MANUFACTURER;	 // The maker/company of the TV
			private int SCREEN_SIZE;	 // The TV's default resolution
			private boolean powerOn;	 // The power state of the TV, ON or OFF
			private int channel;	 // A channel the TV has and can display once turned ON
			private int volume;	 // Loudness of the TV
			
		// Constructor
		/**
		 * This constructor is used to set the TV's default power status to OFF, it's volume to 20, and it's channel to 2.
		 * @param manuBrand The TV's manufacturer
		 * @param sSize The TV's screen size
		 */
		public Television(String manuBrand, int sSize)
		{
			MANUFACTURER = manuBrand;
			SCREEN_SIZE = sSize;
			powerOn = false;
			volume = 20;
			channel = 2;
		}
		
		// Set Method - These set the field values
		
		/**
		 * Set the TV's channel
		 * @param station The TV's channel
		 */
		public void setChannel(int station)
		{
			channel = station;
		}
		
		/**
		 * Turn the TV either ON or OFF based on it's current power state
		 */
		public void power()
		{
			if (!powerOn)
			{
				powerOn = true;
			}
			else
			{
				powerOn = false;
			}
		}
		
		/*
		 * Could do below instead of if statements...
		 * 
		 * void power()
		 * {
		 *     powerOn = !powerOn;
		 * }
		 */
		
		/**
		 * Raise the TV's volume level
		 */
		public void increaseVolume()
		{
			volume += 1;
		}
		
		/**
		 *  Lower the TV's volume level
		 */
		public void decreaseVolume()
		{
			if (volume > 0)
			{
				volume -= 1;
			}
		}
		
		// Get Methods - These get the field values
		
		/**
		 * Get the TV's current volume
		 * @return The TV's volume
		 */
		public int getVolume()
		{
			return volume;
		}
		
		/**
		 *  Get the channel the TV is currently on
		 *  @return The TV's channel
		 */
		public int getChannel()
		{
			return channel;
		}
		
		/**
		 * Get the TV's manufacturer
		 * @return The manufacturer
		 */
		public String getManufacturer()
		{
			return MANUFACTURER;
		}
		
		/**
		 *  Get the TV's resolution
		 *  @return The screen size
		 */
		public int getScreenSize()
		{
			return SCREEN_SIZE;
		}
	}
