
/**
 * This class defines a credit card.
* @author Benjamin Costello
*/

public class CreditCard 
{
	// Member fields/variables
    private Person owner;
    private Money balance;
    private Money creditLimit;
    
    /**
     * Constructor
     * @param newCardHolder initializes the owner
     * @param limit initializes a credit limit
     * @param balance initializes a balance of 0
     */
    public CreditCard(Person newCardHolder, Money limit)
    {
    	this.owner = newCardHolder;
    	this.creditLimit = new Money(limit);
    	this.balance = new Money(0);
    }
    
    // Get methods - These get the field values
    
    /**
     * Gets the balance
     * @return the balance
     */
    public Money getBalance()
    {
        return this.balance = new Money(balance);  
    }
    
    /**
     * Gets the credit limit
     * @return the credit limit
     */
    public Money getCreditLimit()
    {
    	return this.creditLimit = new Money(creditLimit);
    }
    
    /**
     * Gets the person's information
     * @return the person's information
     */
    public String getPersonInfo()
    {
    	return owner.toString();
    }
    
    /**
     * Charges to the credit card by adding the amount to the balance if the credit limit is not exceeded.
     * @param amount money amount being checked
     */
    public void charge(Money amount)
    {
    	Money temp = balance.add(amount);
    	
    	if (temp.compareTo(creditLimit) == -1 || temp.compareTo(creditLimit) == 0)
    		
    		this.balance = temp;
    	else
    	    System.out.println("ERROR: Credit limit will be exceeded, amount is not charged.");
    }
    
    public void payment(Money amount)
    {
    	this.balance = balance.subtract(amount);
    }
}
