
import java.util.Scanner;

/***
 * The Driver to test the Averager class. In this program, 
 * a user enters test scores some basic statistical information
 * is computed.  
 * 
 * @author Benjamin Costello
 *
 */
public class AveragerDriver {

	public static void main(String[] args) {

		Scanner kb = new Scanner(System.in);
		System.out.print("How many scores do you wish to enter? ");
		
		int length = kb.nextInt();
		
		//Task 1 - Create a double array called scores.
		//Make the size of scores match the length indicated by the user.
		//___________________________________
		double[] scores = new double[length];
		
		//Task 2:  Insert score into the i^th position of data		
		double score = 0;
		
		for (int i = 0; i < length; i++)
		{
			System.out.printf("Enter #%d: ", (i+1));
			score = kb.nextDouble();
			//___________________________________
			scores[i] += score;
		}
		
		//Task 3: Create an Averager object and pass to it the
		//scores array.
		//___________________________________
		Averager avg = new Averager(scores);

		System.out.println(); //makes things pretty
		
		//Task 4: Print out the array contents by using
		//the toString method on the Averager object.
		//___________________________________
		System.out.println(avg.toString());
		
		//Task 5: Use the methods  on the Averager object
		//to print out the mean, min, max, and midrange.
		System.out.println();	
		System.out.println("MEAN: " + avg.calculateMean());	
		System.out.println("MIN: " + avg.findMin());	
		System.out.println("MAX: " + avg.findMax());	
		System.out.println("MIDRANGE: " + avg.findMidrange());	
		
		kb.close();
	}


}
