
/**
 * The Averager class contains an array of data and provides methods
 * to compute the mean, min, max, and midrange of the dataset.  
 * 
 * @author Benjamin Costello
 *
 */
public class Averager {
	
	//A field of type double array called data here.
	private double[] data;
	
	//Add a constructor as directed here.
	public Averager(double[] data)
	{
		//Set the data field equal to the passed in array.
		this.data = data;
	}
	
	/***
	 * The calculateMean function calculates the mean of the
	 * data set.
	 * @return The mean of the data set
	 */
	public double calculateMean()
	{
		double sum = 0; //To track the sum of numbers
		
		//Iterate through the array cells, adding the i-th array value to the sum each time.
		for (int i = 0; i < data.length; i++)
		{
			sum += data[i];
		}
		
		//Find the mean by dividing the sum by the length of the array and adding it here.
		return sum / data.length;
	}
	
	/***
	 * The findMin function finds the min of the data set
	 * @return The minimum of the data set
	 */
	public double findMin()
	{
		//The strategy to finding the min is to start by assuming the minimum value is in the 0th element of the array.
		double min = data[0];
		
		//Loop over each element in the array. If the min variable is BIGGER than the current value in the array
		//(so the i-th value), then update min to equal the current array value.
		for (int i = 1; i < data.length; i++)
		{
			if (min > data[i])
				min = data[i];
		}
		
		return min;
	}
	
	/***
	 * The findMax function finds the max of the data set
	 * @return The max of the data set
	 */	
	public double findMax()
	{
		//The strategy to finding the max is to start by assuming the maximum value is in the 0th element of the array.
		double max = data[0];
		
		//Loop over each element in the array. If the max variable is SMALLER than the current value in the array
		//(so the i-th value), then update max to equal the current array value.
		for (int i = 1; i < data.length; i++)
		{
			if (max < data[i])
				max = data[i];
		}
		
		return max;
	}
	
	/***
	 * The findMidrange function finds the 
	 * the number in the middle of the min/max
	 * of the data set
	 * @return The midrange of the data set
	 */
	public double findMidrange()
	{
		//Call the findMin and findMax functions to find the min and max. Then compute the midrange and return it.
		double min = findMin();
		double max = findMax();
		double midrange = (min + max) / 2;
		
		return midrange;
	}
	
	/***
	 * The toString method prints out each element in the
	 * data, separated by spaces.
	 */
	public String toString()
	{
		String temp = "DATA: ";
		
		for (int i = 0; i < data.length; i++)
		{
			//Do not add a comma in front of the first data value.
			if (i == 0)
				temp += data[i];
			else
				temp += ", " + data[i];
		}
		
		return temp;
	}
	

}
