/**
 * The CashRegister_BC class tracks inventory and simulates a purchase.
 * The inventory stock is not changed until the purchase is finalized.
 * @author Benjamin Costello
 */

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class CashRegister_BC extends InventoryItem_BC
{
	//Member variables
	private static final double TAX_RATE = 0.06; //A constant indicating the tax rate of 6%
	private ArrayList<InventoryItem_BC> inventory = new ArrayList<InventoryItem_BC>(); //An ArrayList of InventoryItems that are available for purchase
	private ArrayList<Integer> itemsInCurrentPurchase = new ArrayList<Integer>(); /*An ArrayList of Integers that indicates how many items of each 
	inventory item the user wishes to purchase.*/
	private double total; //The total amount of money from all purchases
	private double pendingPurchaseTotal; //The total amount in the current/ongoing/unfinalized purchase
	
	/**
	 * A constructor that reads in from the inventory.txt file to populate the inventory ArrayList.
	 * @throws IOException
	 */
	public CashRegister_BC() throws IOException
	{
		super(description, description, stockOnHand, pendingPurchaseTotal);
		File myFile = new File("inventory.txt");
		Scanner inputFile = new Scanner(myFile);
		String name;
		String id;
		double price;
		
		while (inputFile.hasNext())
		{
			name = inputFile.next();
			id = inputFile.next();
			price = inputFile.nextDouble();
		}
		inputFile.close();
		
		//Set values in itemsInCurrentPurchase to 0
		for (int i = 0; i < itemsInCurrentPurchase.size(); i++)
		{
			itemsInCurrentPurchase.set(i, 0);
		}
	}
	
	/**
	 * The findItemPosition method takes in a String ID, and returns the
	 * position of the InventoryItem with that ID.
	 * @param id The InventoryItem ID.
	 * @return The position of the InventoryItem.
	 */
	private int findItemPosition(String id)
	{
		int position = 0;
		
		for (int i = 0; i < inventory.size(); i++)
		{
			if (inventory.contains(id))
				position = inventory.indexOf(i);
		}
		return position;
	}
	
	/**
	 * The addToPurchase method accepts a String ID of the item from inventory
	 * that the user wishes to purchase and the amount of units the user wishes to purchase.
	 * @param id The item id from inventory.
	 * @param units The number of units the user wants to purchase.
	 */
	public void addToPurchase(String id, int units)
	{
		itemsInCurrentPurchase
	}
	
	/**
	 * The generateReceipt method determines the pendingPurchaseTotal amount
	 * and generates a String with the Receipt Details.
	 * @return The Receipt Details as a String.
	 */
	public String generateReceipt()
	{
		
	}
	
	/**
	 * The getInventoryList method returns a String detailing the inventory
	 * available for purchase.
	 * @return The String detailing inventory available for purchase.
	 */
	public String getInventoryList()
	{
		String s = "************Inventory On Stock****************\n" + inventory.get(0) + inventory.get(1) + inventory.get(2);
		return s;
	}
	
	/**
	 * The finalizeSale method finalizes the sale and gets the CashRegister ready for the next sale.
	 */
	public void finalizeSale()
	{
		
	}
	
	/**
	 * The getTotal method gets the total of the purchase.
	 * @return The total price of the purchase.
	 */
	public double getTotal()
	{
		
	}
	
	/**
	 * The toString method returns a String representation of the object.
	 * @return The String representation of the object.
	 */
	public String toString()
	{
		String s = "";
		return s;
	}
}
