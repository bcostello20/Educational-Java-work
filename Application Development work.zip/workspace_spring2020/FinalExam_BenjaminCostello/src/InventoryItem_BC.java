/**
 * The InventoryItem_BC class holds data about an inventory item in Georgie's "store".
 * @author Benjamin Costello
 *
 */

public class InventoryItem_BC
{
	//Member variables
	private String description; //A brief description of the item in the "store"
	private String itemId; //An ID for the item
	private int stockOnHand; //The number of items currently in inventory
	private double pricePerUnit; // The retail price for a single item
	
	/**
	 * A constructor that takes in variables and sets them to default values.
	 * @param desc The description of the item in the "store".
	 * @param id The ID for an item.
	 * @param stock The amount of items in the inventory.
	 * @param unitPrice The retail price for a single item.
	 */
	public InventoryItem_BC(String desc, String id, int stock, double unitPrice)
	{
		this.description = desc;
		this.itemId = id;
		this.stockOnHand = stock;
		this.pricePerUnit = unitPrice;
	}
	
	/**
	 * The getDescription method gets an item's description in the "store".
	 * @return The item description.
	 */
	public String getDescription()
	{
		return description;
	}
	
	/**
	 * The setDescription method sets an item's description in the "store".
	 * @param d The item description.
	 */
	public void setDescription(String d)
	{
		description = d;
	}
	
	/**
	 * The getItemid method gets an item's ID.
	 * @return The item's ID.
	 */
	public String getItemid()
	{
		return itemId;
	}
	
	/**
	 * The getStockOnHand method gets the number of items currently in the inventory.
	 * @return The number of items in the inventory.
	 */
	public int getStockOnHand()
	{
		return stockOnHand;
	}
	
	/**
	 * The setStockOnHand method sets the number of items in the inventory.
	 * @param sOH The number of items in the inventory.
	 */
	public void setStockOnHand(int sOH)
	{
		stockOnHand = sOH;
	}
	
	/**
	 * The getPricePerUnit method gets the retail price for a single item in the inventory.
	 * @return The retail price for a single item in inventory.
	 */
	public double getPricePerUnit()
	{
		return pricePerUnit;
	}
	
	/**
	 * The setPricePerUnit method sets the retail price for a single item in the inventory.
	 * @param p The retail price for a single item in inventory.
	 */
	public void setPricePerUnit(double p)
	{
		pricePerUnit = p;
	}
	
	/**
	 * The updateFromPurchase method takes in a number of units being purchased. If that
	 * number of units being purchased is greater than the stock on hand then an
	 * InsufficientInventoryException is thrown.
	 * @param s The number of units being purchased.
	 */
	public void updateFromPurchase(int s) //TO-DO
	{
		
	}
	
	/**
	 * The toString method returns a String representation of the object.
	 * @return The String representation of the object.
	 */
	public String toString() //TO-DO
	{
		String s = "";
		return s;
	}
}
