
//import ????  - For File Reading/Writing
import java.io.*;
import java.util.Scanner;

public class FileIODemo {

	public static void main(String[] args) throws IOException
	{

		String myPromise1 = "1 I promise to get a good grade.";

		String myPromise2 = "2 I promise to learn java.";



		/* *********************************
		 * LESSON 1:  WRITING TO A FILE 
		 * **********************************/
		String fileName = "promise.txt";  //Where does this get saved?

		//PrintWriter pw = new PrintWriter(fileName);
		//pw.println(myPromise1);
		//pw.println(myPromise2);
		//pw.close();

		/* *********************************
		 * LESSON 2:  DONT FORGET TO CLOSE
		 * **********************************/

		/*PrintWriter pw = new PrintWriter(fileName);

		for (int i = 0; i < 100000; i++)
		   	{
		   		pw.println(i + " ");
		   	}
		pw.close();*/



		/* *********************************************
		 * LESSON 3:  What if we don't want to save to the
		 * default location?
		 * *********************************************/
//		
//		fileName = "C:\\Users\\Student\\Desktop\\promise.txt";
//		PrintWriter pw = new PrintWriter(fileName);
//		pw.println(myPromise1);
//		pw.println(myPromise2);
//		pw.close();


		/* *********************************************
		 * LESSON 4: Do we need double backslashes 
		 * with user input from the console?
		 * *********************************************/


		
//		   System.out.println("Please enter file name with a path: ");
//		   Scanner kb = new Scanner(System.in);
//		   String fileNameConsole = kb.nextLine();
//		   		   	
//		   PrintWriter pw2 = new PrintWriter(fileNameConsole);
//		   pw2.print("Howdy");
//		   pw2.close();

		/* *********************************************
		 * LESSON 4:  Does PrintWriter APPEND or OVERWRITE
		 * an existing file?
		 * *********************************************/

		   //overwrites!


		/* *********************************************
		 * LESSON 5:  What if we want to print in a method?
		 * Still need it in main as well as exceptions
		 * in Java "bubble up" if unhandled.
		 * *********************************************/

		   printPiToFile();


		/* *********************************************
		 * LESSON 6:  What if we want to append and not overwrite?
		 * *********************************************/

//		   FileWriter fw = new FileWriter("appendExample.dat", true);
//		   
//		   PrintWriter pw4 = new PrintWriter(fw);
//		   pw4.print("I want to append");
//		   pw4.print("I want to append");
//		   pw4.print("I want to append");
//		   pw4.close();
		
		/* *********************************************
		 * LESSON 7: How do we READ from a file?
		 * Open up extensions.dat to see what is inside
		 * *********************************************/

		File myFile = new File("extensions.dat");
		
		Scanner inputFile = new Scanner(myFile);
		
		String line;
		String lname;
		int ext;
		
		while(inputFile.hasNext()) //the EOF has not been hit
		{
			//line = inputFile.nextLine();
			lname = inputFile.next();
			ext = inputFile.nextInt();
			//System.out.println(line);
			System.out.printf("NAME: %-10s EXTENSION: %d\n", lname, ext);
		}
		
		inputFile.close();
			
			
		
		System.out.println("Program complete");

	}


	 public static void printPiToFile() throws IOException
	   {
	   	   String fileName = "pi.dat";
		   PrintWriter pw3 = new PrintWriter(fileName);
		   pw3.println("3.1415926535897932384");
		   pw3.close();
	   }
	 

}
