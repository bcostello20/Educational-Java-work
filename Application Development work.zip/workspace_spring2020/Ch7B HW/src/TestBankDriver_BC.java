import java.util.ArrayList;
import java.util.Scanner;

public class TestBankDriver_BC 
{

	public static void main(String[] args) 
	{
		//Declare an ArrayList
		ArrayList<String> myQuestions = new ArrayList<String>();
		
		//A list of 5 questions
		myQuestions.add("What year is it?");
		myQuestions.add("What is the name of the university?");
		myQuestions.add("What month is it?");
		myQuestions.add("What is 12 x 12?");
		myQuestions.add("What is 8 + 8?");
		
		//Ask the user which topic they would like to see
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Topics: Year, School, Month, Multiplication, Addition\n");
		System.out.println("What topic would you like to see?: ");
		String topic = keyboard.nextLine();
		
		//Call the searchForTopic method
		searchForTopic(topic, myQuestions);
		
	}
	
	public static void searchForTopic(String topic, ArrayList<String> myQuestions)
	{
			if (topic == "Year")
			{
				System.out.println(myQuestions.get(0));
			}
			else if (topic == "School")
			{
				System.out.println(myQuestions.get(1));
			}
	}

}
