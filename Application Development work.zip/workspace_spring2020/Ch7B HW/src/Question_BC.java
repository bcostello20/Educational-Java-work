
public class Question_BC 
{
	// Member fields
	private String topic = ""; //Topic of the question
	private String text = ""; //Contains the question's text
	private boolean answer = false;
	
	public Question_BC(String topic, String text)
	{
		this.topic = topic;
		this.text = text;
	}

	/**
	 * Get the topic
	 * @return the topic
	 */
	public String getTopic() 
	{
		return topic;
	}

	/**
	 * Set the topic
	 * @param topic the topic to set
	 */
	public void setTopic(String topic) 
	{
		this.topic = topic;
	}

	/**
	 * Get the text
	 * @return the text
	 */
	public String getText() 
	{
		return text;
	}

	/**
	 * Set the text
	 * @param text the text to set
	 */
	public void setText(String text) 
	{
		this.text = text;
	}
	
	public String toString()
	{
		String s = "You chose topic of: " + topic;
		return s;
	}
}
