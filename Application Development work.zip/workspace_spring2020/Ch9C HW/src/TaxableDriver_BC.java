/**
 * The TaxableDriver_BC driver sets up an object array with 3
 * element slots. It also creates the objects in each array element spot.
 * It then loops through the object array calling the getReceiptItem
 * on each object to display their information to the console for the user.
 * Lastly it calculates and displays the total tax.
 * @author Benjamin Costello
 *
 */

public class TaxableDriver_BC 
{

	public static void main(String[] args) 
	{
		//Variables
		final int SIZE = 3; //Size of the array
		
		//Array of taxable items
		Taxable_BC[] items = new Taxable_BC[SIZE];
		
		items[0] = new CigarettePack_BC(20);
		items[1] = new Tire_BC(2, 2);
		items[2] = new CarFuel_BC(CarFuel_BC.FuelType.DIESEL_GAS, 15);
		
		//Loop through the Taxable_BC array and print out the correct information
		for (int i = 0; i < items.length; i++)
		{
			System.out.println(items[i].getReceiptItem());
		}
		
		//Calculate the total tax and then display it to the console
		double totalTax = 11.205 + (20 * 0.13) + 2;
		
		System.out.println("Total Tax: $" + String.format("%.3f", totalTax));
	}

}
