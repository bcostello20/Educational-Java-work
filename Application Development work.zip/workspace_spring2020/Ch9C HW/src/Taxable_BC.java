/**
 * An interface for calculating tax and printing a receipt.
 * @author Benjamin Costello
 *
 */

public interface Taxable_BC 
{
	public double calculateTax();
	
	public String getReceiptItem();
}
