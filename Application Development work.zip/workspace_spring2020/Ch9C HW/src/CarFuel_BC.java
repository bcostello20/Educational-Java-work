/**
 * The CarFuel_BC class contains a fuel type enumeration. It also takes in a fuel type
 * and number of gallons. It calculates the tax for any of the three types of fuel
 * included and then prints a receipt showing related information.
 * @author Benjamin Costello
 *
 */

public class CarFuel_BC implements Taxable_BC
{
	//Fuel type enumeration
	public enum FuelType {MOTOR_GAS, DIESEL_GAS, HYDROGEN};
	
	//Member variables
	private FuelType fuelType; //The fuel type used
	private double gallons; //How many gallons used
	
	public static final double MOTOR_FUEL = 0.582; //Tax per gallon of motor fuel
	public static final double HYDROGEN = 0.582; //Tax for the equivalent of a gallon
	public static final double DIESEL_FUEL = 0.747; //Tax per gallon of diesel fuel
	
	/**
	 * A constructor that takes in a fuel type and gallons amount
	 * and sets their values.
	 * @param fT The fuel type.
	 * @param g The gallons amount.
	 */
	public CarFuel_BC(FuelType fT, double g)
	{
		this.fuelType = fT;
		this.gallons = g;
	}
	
	/**
	 * The calculateTax method checks what type of fuel was entered
	 * and calculates it with the number of gallons entered to get the tax.
	 * @return The tax.
	 */
	@Override
	public double calculateTax()
	{
		double theTax = 0;
		
		if (fuelType == FuelType.MOTOR_GAS)
			theTax = MOTOR_FUEL * gallons;
		else if (fuelType == FuelType.HYDROGEN)
			theTax = HYDROGEN * gallons;
		else if (fuelType == FuelType.DIESEL_GAS)
			theTax = DIESEL_FUEL * gallons;
		
		return theTax;
	}
	
	/**
	 * The getReceiptItem method acts as a toString method and displays
	 * related information to the console for the user.
	 * @return A string representation of the object.
	 */
	@Override
	public String getReceiptItem()
	{
		String s = String.format("%.3f", gallons) + " gallons" + " of " + fuelType + " fuel: " + String.format("%.3f", calculateTax()) + " in tax";
		return s;
	}
}
