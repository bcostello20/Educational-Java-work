/**
 * The CigarettePack_BC class takes in an amount purchased and calculates the 
 * tax for the amount of cigarettes bought and prints a receipt showing related
 * information.
 * @author Benjamin Costello
 *
 */

public class CigarettePack_BC implements Taxable_BC
{
	//Member variables
	private double amountPurchased; //Amount of cigarettes bought
	public static final double CIGARETTE_TAX = 0.13; //Cigarette tax per cigarette
	
	/**
	 * A constructor that takes in an amount purchased and sets the value.
	 * @param aP The amount purchased.
	 */
	public CigarettePack_BC(double aP)
	{
		this.amountPurchased = aP;
	}
	
	/**
	 * The calculateTax method calculates the tax for number of
	 * cigarettes purchased.
	 * @return The tax for cigarettes purchased.
	 */
	@Override
	public double calculateTax()
	{
		return CIGARETTE_TAX * amountPurchased;
	}
	
	/**
	 * The getReceiptItem method acts as a toString method and displays
	 * related information to the console for the user.
	 * @return A string representation of the object.
	 */
	@Override
	public String getReceiptItem()
	{
		String s = "Pack of " + String.format("%.0f", amountPurchased) + " cigarettes: $" + String.format("%.3f", calculateTax()) + " in tax";
		return s;
	}
}
