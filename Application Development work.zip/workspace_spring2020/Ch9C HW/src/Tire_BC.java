/**
 * The Tire_BC class gets and stores information about used and new tires bought.
 * It also calculates the tax for the tires and prints to the console
 * related information for the user.
 * @author Benjamin Costello
 *
 */

public class Tire_BC implements Taxable_BC
{
	//Member variables
	private int newTire; //Amount of new tires purchased
	private int usedTire; //Amount of used tires purchased
	
	public static final double NEW_TIRE = 1.00; //Tax amount for a new tire
	public static final double USED_TIRE = 0; //Tax amount for a used tire
	
	/**
	 * A constructor that takes in a number of new tires
	 * and a number of used tires and sets their values.
	 * @param nT The number of new tires.
	 * @param uT The number of used tires.
	 */
	public Tire_BC(int nT, int uT)
	{
		this.newTire = nT;
		this.usedTire = uT;
	}
	
	double newTireTotal = 0;
	double usedTireTotal = 0;
	
	/**
	 * The calculateTax method calculates tax for the number
	 * of new and used tires purchased.
	 * @return The tax for the tires.
	 */
	@Override
	public double calculateTax()
	{
		newTireTotal = NEW_TIRE * newTire;
		usedTireTotal = USED_TIRE * usedTire;
		
		return newTireTotal + usedTireTotal;
	}
	
	/**
	 * The getReceiptItem method acts as a toString method and displays
	 * related information to the console for the user.
	 * @return A string representation of the object.
	 */
	@Override
	public String getReceiptItem()
	{
		String s = "Used tire: $" + String.format("%.3f", usedTireTotal) + " in tax" + "\nUsed tire: $" + String.format("%.3f", usedTireTotal) + " in tax" 
	+ "\nNew tire: $" + String.format("%.3f", NEW_TIRE) + " in tax" + "\nNew tire: $" + String.format("%.3f", NEW_TIRE) + " in tax";
				
		return s;
	}
}
