
//add Scanner import
import java.util.Scanner;
//add FileWriter/PrintWriter import
import java.io.*;

/**
   This class reads numbers from a file, calculates the
   mean and standard deviation, and writes the results
   to a file.
   @author Benjamin Costello
*/

public class StatsCalculator 
{
   // Part of TASK #1 - Add the throws clause 
   public static void main(String[] args) throws IOException
   {
      double sum = 0;      // The sum of the numbers
      int count = 0;       // Tracks how many numbers are in the file
      double mean = 0;     // The average of the numbers
      double stdDev = 0;   // The standard deviation of the numbers
      double difference;   // The difference between a value in the file and the mean

      // Create an object of type Scanner
      Scanner keyboard = new Scanner (System.in);
      String filename;     // The user input file name

      // Prompt the user and read in the file name
      System.out.println("This program calculates " +
                         "statistics on a file " +
                         "containing a series of numbers");
      System.out.print("Enter the input file name:  ");
      filename = keyboard.nextLine();

      keyboard.close();
      
      // ADD LINES FOR TASK #2 HERE
      // Create a File object passing it the filename
      File myFile = new File(filename);
      // Create a Scanner object passing the File object
      Scanner inputFile = new Scanner(myFile);
      // Loop until you are at the end of the file
      // Read in each double value from the file
  	  // Add the value to sum.  
  	  // Increment the counter
      // Close the input file
      // Calculate the mean
      double value;
      while (inputFile.hasNext())
      {
    	  value = inputFile.nextDouble();
    	  sum += value;
    	  count++;
      }
      inputFile.close();
      mean = sum / count;
      

      // ADD LINES FOR TASK #3 HERE
      // Reinitialize the sum to 0.  Note: Now we will use the sum variable
	  //       to sum up the squared difference between each point and the mean.
      // Reinitialize the number of numbers added
	  // We're re-reading the file a second time but we had to clsoe all 
	  // of the resources above.  So create two new objects (a File Object and a Scanner object)
	  // that link to the same file as before.

	 // Loop until you are at the end of the file
      // 	Get the double off of each line and subtract the mean from TASK #2 from it
	  //    Store the subtraction in the difference variable.
      // 	Add the square of the difference to the sum
      // 	Increment the counter
      // Close the input file
     
      // Store the calculated standard deviation.  
     
      File myFile2 = new File(filename);
      Scanner inputFile2 = new Scanner(myFile2);
      
      sum = 0;
      count = 0;
      String value2;
      
      while (inputFile2.hasNext())
      {
    	  value2 = inputFile2.nextLine();
    	  difference = Math.pow((Math.abs(Double.parseDouble(value2)) - mean), 2);
    	  sum += difference;
    	  count++;
      }
      inputFile2.close();
      stdDev = sum / count - 1;
      stdDev = Math.sqrt(stdDev);
      
      // ADD LINES FOR TASK #1 HERE
      // Create a FileWriter object using "Results.txt" 
      FileWriter fw = new FileWriter("Results.txt");
      // Create a PrintWriter object passing the FileWriter object
      PrintWriter pw = new PrintWriter(fw);
      // Print the mean and standard deviation to the output file - Be sure to use 3 decimals
      pw.println("Sample Mean: " + mean);
      pw.println("Sample Standard Deviation: " + stdDev);
      // Close the output file
      pw.close();
    }
}
