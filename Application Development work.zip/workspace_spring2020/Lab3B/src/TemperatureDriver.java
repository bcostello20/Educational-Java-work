/**
 * Lab 3B: More Practice on Classes
 * TemperatureDriver.java, Temperature.java
 * This program asks the user for a Fahrenheit temperature. The program will use a Temperature class, with the value entered--
 * by the user passed to the constructor. The program will then call the object's methods to display the temperature--
 * converted to celsius and kelvin.
 * @author Benjamin Costello
 *
 */

import java.util.Scanner;

public class TemperatureDriver {

	public static void main(String[] args) 
	{
		 // Create a Scanner object to read from the keyboard
	      Scanner keyboard = new Scanner (System.in);
	      
	      // Declare variables
	      double temperature;	// The user's fahrenheit temperature
	      
	      // Ask the user for a temperature in fahrenheit
	      System.out.println("Enter a fahrenheit temperature: ");
	      temperature = keyboard.nextDouble();
	      
	      // Declare and instantiate a Temperature object
	      Temperature theTemp = new Temperature(temperature);
	      
	      // Display the temperature in Celsius and Kelvin
	      theTemp.setFahrenheit(temperature);
	      System.out.println(theTemp.toString());
	      System.out.println("Celcius temperature: " + theTemp.getCelsius());
	      System.out.println("Kelvin temperature: " + theTemp.getKelvin());
	      
	      // Close the scanner
	      keyboard.close();
	}

}
