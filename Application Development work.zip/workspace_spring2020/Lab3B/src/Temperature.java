/**
 * A temperature class
 * This class contains a constructor with a default double value for a fahrenheit temperature. It also has accessor and mutator--
 * methods to convert the fahrenheit temperature to celsius and kelvin.
 * @author Benjamin Costello
 *
 */
public class Temperature 
{
    // Declare member variables
	private double fTemp;
	
	// Constructor
	/**
	 * This constructor sets the default values for the fields.
	 * @param aTemp The fahrenheit temperature
	 */
	public Temperature(double aTemp)
	{
		fTemp = aTemp;
	}
	
	// Get methods - These get the field values
	
	/**
	 * Gets the fahrenheit temperature
	 * @return The fahrenheit temperature
	 */
	public double getFahrenheit()
	{
		return fTemp;
	}
	
	/**
	 * Gets the celsius temperature
	 * @return The celsius temperature
	 */
	public double getCelsius()
	{
		double celsius = (5.0/9.0) * (fTemp - 32);
		return celsius;
	}
	
	/**
	 * Gets the kelvin temperature
	 * @return The kelvin temperature
	 */
	public double getKelvin()
	{
		double kelvin = ((5.0/9.0) * (fTemp - 32)) + 273;
		return kelvin;
	}
	
	/**
	 * Puts the fahrenheit temperature into a String
	 * @return The String s
	 */
	public String toString()
	{
		String s = "Fahrenheit temperature: " + fTemp;
		return s;
	}
	
	// Set methods - These set the field values
	
	/**
	 * Sets the fahrenheit temperature
	 * @param temp The fahrenheit temperature
	 */
	public void setFahrenheit(double temp)
	{
		fTemp = temp;
	}
}
