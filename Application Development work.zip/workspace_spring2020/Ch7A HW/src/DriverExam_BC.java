/**
 * This class demonstrates a driver exam grader and has the fields and methods which do several steps.
 * DriverExam_BC.java
 * @author Benjamin Costello
 */

import java.util.Arrays;

public class DriverExam_BC 
{
    //Member Fields
	private static char[] examArray = {'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A'}; //Exam correct answers array
	char[] studentAnswers = new char[20]; //Student answers array
	boolean passed = false;
	
	/**
	 * A constructor
	 * @param studentAnswers an array of answers given by the student
	 */
	public DriverExam_BC(char[] studentAnswers)
	{
		this.studentAnswers = studentAnswers;
	}
	
	/**
	 * Check to see if both arrays of chars match
	 * @return passed true if answers in both arrays match, otherwise false
	 */
	public boolean passed()
	{
		int amountCorrect = 0;
		
		for (int i = 0; i < examArray.length; i++)
		{
			if (studentAnswers[i] == examArray[i])
				amountCorrect++;
		}
		
		if (amountCorrect >= 15)
			return passed = true;
		else
			return passed = false;
	}
	
	/**
	 * See how many student answers match the actual exam answers
	 * @return the amount of correct student answers
	 */
	public int totalCorrect()
	{
		int countCorrect = 0; //Counter for how many student answers were correct
		
		for (int i = 0; i < examArray.length; i++)
		{
			if (studentAnswers[i] == examArray[i])
				countCorrect++;
		}
		
		return countCorrect;
	}
	
	/**
	 * See how many student answers do not match the actual exam answers
	 * @return the amount of incorrect student answers
	 */
	public int totalIncorrect()
	{
		int countIncorrect = 0; //Counter for how many student answers were incorrect
		
		for (int i = 0; i < examArray.length; i++)
		{
			if (studentAnswers[i] != examArray[i])
				countIncorrect++;
		}
		
		return countIncorrect;
	}
	
	/**
	 * Check to see how many questions the student missed
	 * @return the question numbers the student missed
	 */
	public String questionsMissed()
	{
		//int[] missed = new int[20];
		
		String missedString = "";
		
		for (int i = 0; i < studentAnswers.length; i++)
		{
			if (studentAnswers[i] != examArray[i])
				//missed[i] = i + 1;
				missedString += " " + (i + 1) + ",";
		}
		
		return missedString;
	}
	
	/**
	 * Converts the students' answers array to a string
	 * @return the array of chars of the student's answers to a string
	 */
	public String toString()
	{
		//String s = "Your answers were: " + studentAnswers.toString();
		
		char[] s = new char[20];
		
		for (int i = 0; i < studentAnswers.length; i++)
		{
			s[i] = studentAnswers[i];
		}
		
		return Arrays.toString(s);
	}
}
