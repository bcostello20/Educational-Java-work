
/**
 * This program asks a user to enter their answers for a driver exam. It only accepts the letters A, B, C, or D as answers and performs input validation.
 * The program will display the results using the DriverExam class fields and methods.
 * DriverProgram_BC.java
 * @author Benjamin Costello
 *
 */

import java.util.Scanner;

public class DemoProgram_BC 
{

	public static void main(String[] args) 
	{
		//Create the char array to hold student answers
		char[] studentAnswers = new char[20];
		
		//Ask the student for his/her answers
		Scanner keyboard = new Scanner(System.in); //Scanner object
		
		int questionCounter = 0; //The current question
		
		System.out.println("You may answer only using A, B, C, or D.\n"); //Instructions for the student
		
		while (questionCounter < studentAnswers.length)
		{
			System.out.println("Enter your answer for question " + (questionCounter + 1) + ": ");
			
			char answer = keyboard.next().charAt(0); //Student's answer for current question
			
			while (answer != 'A' && answer != 'B' && answer != 'C' && answer != 'D')
			{
				System.out.println("The answer you gave was invalid. Please try again only using A, B, C, or D.");
				System.out.println("Enter your answer for question " + (questionCounter + 1) + ": ");
					
				answer = keyboard.next().charAt(0); //Student's answer for current question	
			}
			studentAnswers[questionCounter] = answer; //Set the current i-th position of the studentAnswers array equal to the student's answer given
			questionCounter++;
		}
		
		//Create the DriverExam object
		DriverExam_BC de = new DriverExam_BC(studentAnswers);
		
		//Display the results
		System.out.println("Passed?: " + de.passed());
		System.out.println("Total correct: " + de.totalCorrect());
		System.out.println("Total incorrect: " + de.totalIncorrect());
		System.out.println("You missed #" + de.questionsMissed());
		System.out.println("Your answers were: " + de.toString());
		
		//Close the Scanner
		keyboard.close();
	}

}
