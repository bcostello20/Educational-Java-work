/**
 * Benjamin Costello
 */
import java.util.Scanner;

public class CircleDriver_BC {

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter a circle's radius: ");
		double theRadius = keyboard.nextDouble();
		
		Circle_BC circle = new Circle_BC(theRadius);
		
		System.out.printf("Radius: %15.5f\nDiameter: %13.5f\nCircumference: %7.5f\nArea: %17.5f", circle.getRadius(), circle.getDiameter(), circle.getCircumference(), circle.getArea());
		System.out.println("\n" + circle.toString());
		
		keyboard.close();
	}

}
