/**
 * 
 * @author Benjamin Costello
 *
 */
public class Circle_BC 
{
    private double radius;
    
    public Circle_BC(double radius)
    {
    	this.radius = radius;
    }
    
    public void setRadius(double r)
    {
    	radius = r;
    }
    
    public double getRadius()
    {
    	return radius;
    }
    
    public double getArea()
    {
    	return Math.PI * Math.pow(radius, 2);
    }
    
    public double getDiameter()
    {
    	return 2 * radius;
    }
    
    public double getCircumference()
    {
    	return 2 * Math.PI * radius;
    }
    
    public String toString()
    {
    	String s = String.format("The circle's radius (from toString): %s", radius);
    	return s;
    }

    
    
    
}
