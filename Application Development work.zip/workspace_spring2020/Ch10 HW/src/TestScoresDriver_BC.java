/**
 * TestScoresDriver_BC program
 * This program asks the user to enter how many test scores and then the test scores.
 * It then checks to see if the test scores being entered are valid -
 * not less than 0 or greater than 100.
 * If any test score entered is invalid, the program will throw an exception
 * with an understandable error message.
 * @author Benjamin Costello
 * 
 */

import java.util.Scanner;

public class TestScoresDriver_BC 
{

	public static void main(String[] args)
	{
		//Create the Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		//Ask the user how many scores they are entering
		System.out.println("How many test scores are being entered?: ");
		
		//Set variable to a length for scores being entered
		int scoresLength = keyboard.nextInt();
		
		//Set the array to the length
		int testScores[] = new int[scoresLength];
		
		
		
		//Try to loop through the array and catch any number entered that is less than 0 or greater than 100
		//by throwing a custom InvalidTestScore exception.
		try
		{
		for (int i = 0; i < scoresLength; i++)
		{
			//Ask the user for the test scores
			System.out.println("Enter test score " + (i + 1) +": ");
			int userInput = keyboard.nextInt();
			testScores[i] = userInput;
			
			if (testScores[i] < 0 || testScores[i] > 100)
				throw new InvalidTestScore_BC();
			
		}
		//Create the TestScores_BC object and pass it the testScores array
		TestScores_BC ts = new TestScores_BC(testScores);
		//Display the average test score.
		System.out.println("\nAverage test score: " + ts.getAverage());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
