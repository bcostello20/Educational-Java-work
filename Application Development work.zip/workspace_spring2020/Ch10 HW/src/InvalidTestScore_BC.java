/**
 * InvalidTestScore_BC class
 * This is an exception that is thrown by the TestDriver_BC class
 * when it receives a test score that is less than 0
 * or greater than 100.
 * @author Benjamin Costello
 *
 */

public class InvalidTestScore_BC extends Exception
{
	/**
	 * Constructor
	 */
	public InvalidTestScore_BC()
	{
		super("ERROR: You entered an invalid number of less than 0 or greater than 100.");
	}
}
