/**
 * TestScores_BC class
 * This class stores an array of integer test scores.
 * It has a method to get the average test score from the array of test scores.
 * @author Benjamin Costello
 *
 */

public class TestScores_BC
{
	//Member variables
	private int testScores[]; //An integer array of test scores
	
	/**
	 * A constructor that accepts an array of test scores as its parameter.
	 * @param testScores An integer array of test scores.
	 */
	public TestScores_BC(int testScores[])
	{
		this.testScores = testScores;
		
		try
		{
		for (int i = 0; i < testScores.length; i++)
		{	
			if (testScores[i] < 0 || testScores[i] > 100)
				throw new InvalidTestScore_BC();
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * The getAverage method gets the average test score out of however many there are in total.
	 * @return The average test score.
	 */
	public double getAverage()
	{
		double total = 0;
		
		for (int i = 0; i < testScores.length; i++)
		{
			double currentScore = testScores[i];
			total += currentScore;
		}
		
		double average = total / testScores.length;
		return average;
	}
}
