/**
 * The Program2_BC file demonstrates using a try-catch on an exception but continues running the program to get the results.
 * @author Benjamin Costello
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;

public class Program2_BC {

  public static void main(String[] args) {

    int total = 0;
    int num = 0;

    File myFile = null;
    Scanner inputFile = null;
try
{
    myFile = new File("inFile.txt");
    inputFile = new Scanner(myFile);

	

    while (inputFile.hasNext())  
    {
      try {
      num = inputFile.nextInt();
      total += num;
      }
      catch (InputMismatchException ime)
      {
      	System.out.println("Illegal value found");
          inputFile.next();        // clear the scanner buffer
      }
    } // end while

    System.out.println("The total value is " + total);
  }
catch (FileNotFoundException fnf)
{
	//display total of 0
	System.out.println(fnf.getMessage());
}

  }
}
