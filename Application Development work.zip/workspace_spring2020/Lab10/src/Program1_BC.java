/**
 * The Program1_BC file demonstrates using a try-catch on an exception but terminates the program before getting results.
 * @author Benjamin Costello
 */

import java.util.Scanner;
import java.util.InputMismatchException;

public class Program1_BC {

  public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);

        int num = 0;

        try {
        	
        do {
              System.out.println("Enter a number between 1 and 10");    
              num = scan.nextInt();

              if (num < 1 || num > 10)
              
              System.out.println("\nIllegal value, " + num + " entered.  Please try again.");
           }  while (num < 1 || num > 10);    

              System.out.println("\nValue correctly entered! Thank you.");
        }
        catch (InputMismatchException ime) {
            
            System.out.println("Enter whole numbers only, with no spaces or other characters");
            scan.next();        // clear the scanner buffer
         }
        scan.close();
      }
 }
