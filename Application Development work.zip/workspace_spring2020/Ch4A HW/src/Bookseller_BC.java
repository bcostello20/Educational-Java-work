/**
 * @author Benjamin Costello
 * Bookseller_BC.java
 * This program uses a switch case to determine how many points a user receives based on the amount of books they purchased--
 * in a month.
 */
import java.util.Scanner;

public class Bookseller_BC 
{

	public static void main(String[] args) 
	{
		int booksPurchased;	// Number of books purchased by the user
		
		// Create a Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		// Ask user for amount of books purchased
		System.out.println("Enter number of books purchased this month: ");
		booksPurchased = keyboard.nextInt();
		
		// Using a switch case, see what number the user entered and award he/she the respective points
		switch (booksPurchased)
		{
		case 0:
			System.out.println("You earned 0 points.");
			break;
		case 1:
			System.out.println("You earned 5 points.");
			break;
		case 2:
			System.out.println("You earned 15 points.");
			break;
		case 3:
			System.out.println("You earned 30 points.");
			break;
		case 4:
			System.out.println("You earned 60 points.");
			break;
		default:
			if (booksPurchased > 4)
			    System.out.println("You earned 60 points.");
			else if (booksPurchased < 0)
				System.out.println("You earned 0 points.");
		}
		
		// Close the Scanner
		keyboard.close();
	}

}
