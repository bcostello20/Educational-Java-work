/**
 * RouletteDriver_BC.java
 * @author Benjamin Costello
 * This program simulates a roulette wheel. Pockets are numbered from 0 to 36, with an additional pocket numbered 00. The colors of the pockets--
 * are green, black, and red. If the user matches pocket number with a randomly generated number he/she wins $1000. If the user matches pocket color--
 * with a randomly generated color he/she wins $500. If the user does not win anything the program will say so.
 */
import java.util.Scanner;
import java.util.Random;

public class RouletteDriver_BC 
{

	public static void main(String[] args) 
	{
		int randomNum; // A random generated number used by the second RoulettePocket_BC object
		
		// Create Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		// Create a Random object
		Random randomGenerator = new Random();
		
		System.out.println("Enter a pocket number: ");
		String pocketNum = keyboard.nextLine();
		
		// Create a RoulettePocket_BC object
		RoulettePocket_BC rPocket = new RoulettePocket_BC(Integer.parseInt(pocketNum));
		
		// Create a second RoulettePocket_BC object that is a random number
		RoulettePocket_BC anotherRPocket = new RoulettePocket_BC(randomNum = randomGenerator.nextInt(36) + 00);
		
		// Display the pocket number and color
		if (rPocket.getPocketColor() == "green")
			System.out.println("The pocket " + rPocket.getPocketNumber() + " is " + rPocket.getPocketColor());
		else if (rPocket.getPocketColor() == "red")
			System.out.println("The pocket " + rPocket.getPocketNumber() + " is " + rPocket.getPocketColor());
		else if (rPocket.getPocketColor() == "black")
			System.out.println("The pocket " + rPocket.getPocketNumber() + " is " + rPocket.getPocketColor());
		else
		{
			if (pocketNum != "0" || pocketNum != "00" || Integer.parseInt(pocketNum) > 36)
			    System.out.println("Your input of " + rPocket.getPocketNumber() + " is invalid. Please choose a number between 00/0 and 36.");
			System.exit(0);
		}
		
		// Display the random pocket number and color
		System.out.println("The random pocket " + anotherRPocket.getPocketNumber() + " is " + anotherRPocket.getPocketColor());
		
		// Check to see if the random number gives a matching pocket or matching color
		if (Integer.parseInt(pocketNum) == randomNum)
			System.out.println("You win $1000!");
		else if (rPocket.getPocketColor() == anotherRPocket.getPocketColor())
			System.out.println("You win $500!");
		else
			System.out.println("You didn't win any money prize.");
		
		// Close the Scanner
		keyboard.close();
	}

}
