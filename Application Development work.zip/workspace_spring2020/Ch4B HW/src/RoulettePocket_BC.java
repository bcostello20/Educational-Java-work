/**
 * A RoulettePocket_BC class.
 * @author Benjamin Costello
 *
 */
public class RoulettePocket_BC 
{
	// Member variables/fields
	private int pocketNumber;	// The pocket number
	private String pocketColor = "";	// The pocket color
	
    // Constructor
	/**
	 * A constructor that takes in a pocket number.
	 * @param pocketNumber The pocket number
	 */
	public RoulettePocket_BC(int pocketNumber)
	{
		this.pocketNumber = pocketNumber;
	}
	
	// Get method - These get the field values
	/**
	 * Gets the pocket number.
	 * @return The pocket number
	 */
	public int getPocketNumber()
	{
		return pocketNumber;
	}
	
	/**
	 * Gets the pocket color.
	 * @return The respective pocket color
	 */
	public String getPocketColor()
	{
		if (pocketNumber == 0 || pocketNumber == 00)
			pocketColor = "green";
		else if (pocketNumber >= 1 && pocketNumber <= 10)
			pocketColor = "black";
		else if (pocketNumber > 10 && pocketNumber <= 18)
			pocketColor = "red";
		else if (pocketNumber > 18 && pocketNumber <= 28)
			pocketColor = "black";
		else if (pocketNumber > 28 && pocketNumber <= 36)
			pocketColor = "red";
		return pocketColor;
	}
}
