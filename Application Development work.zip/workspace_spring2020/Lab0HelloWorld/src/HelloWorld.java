
public class HelloWorld {

	public static void main(String[] args) {
		
		//This line is a comment.
		
		/*
		 * Name: Benjamin Costello
		 * HW: Lab0HelloWorld, HelloWorld.java
		 */
		
		System.out.println("Hello World");
		
		//System.out.println("I love Java!");
		
		int age = 27;
		
		System.out.println(age);
		
		System.out.println("The age of bob is: " + age);

	}

}
