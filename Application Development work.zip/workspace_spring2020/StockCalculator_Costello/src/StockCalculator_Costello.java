/**
 * Ch. 2 Programming Assignment
 * Benjamin Costello
 * StockCalculator_Costello.java
 * This script is a stock calculator that asks the user for shares purchased, amount paid per share, and how much per share the user plans--
 * to sell the stock. It then calculates each amount and the commissions to be paid for purchasing and selling the stock. It displays the--
 * results to the user including the total profit the user made after the selling of the stock and commissions paid.
 */

import java.util.Scanner;

public class StockCalculator_Costello {

	public static void main(String[] args) 
	{	
		// Variables
		int sharesPurchased;	// How many shares Joe purchased
		int amountPerShare;		// Amount Joe paid per share
		int amountPerSold;		// Amount per share that the stock is sold for
		double totalAmountPaid;	// Total amount paid for the stock
		double totalAmountSoldFor;		// Total amount the stock was sold for
		double commissionAtPurchase;		// Commission amount at purchase
		double commissionWhenSold;		// Commission amount when sold
		double totalProfit;		// Total profit made from selling the stock and paying commissions
		final double COMMISSION_PRICE = 0.02;		// Commission amount for purchase and selling of the stock
		
		// Create a Scanner object for keyboard input.
		Scanner keyboard = new Scanner(System.in);
		
		// Prompt the user to enter how many shares Joe purchased.
		System.out.print("Enter the number of shares that you purchased: ");
		sharesPurchased = keyboard.nextInt();
		
		// Prompt the user to enter the amount paid per share.
		System.out.print("Enter the amount that you paid per share: ");
		amountPerShare = keyboard.nextInt();
		
		// Prompt the user to enter the amount per share that the stock is sold for.
		System.out.print("Enter the amount (per share) that the stock is sold for: ");
		amountPerSold = keyboard.nextInt();
		
		System.out.println();	// Spacing
		
		// Calculate the total amount paid for the stock.
		totalAmountPaid = sharesPurchased * amountPerShare;
		
		// Calculate commission paid at purchase.
		commissionAtPurchase = totalAmountPaid * COMMISSION_PRICE;
		
		// Calculate the total amount the stock was sold for.
		totalAmountSoldFor = sharesPurchased * amountPerSold;
		
		// Calculate commission paid when sold.
		commissionWhenSold = totalAmountSoldFor * COMMISSION_PRICE;
		
		// Calculate the total profit made from selling the stock and paying commissions.
		totalProfit = totalAmountSoldFor - totalAmountPaid - commissionAtPurchase - commissionWhenSold;
		
		// Display the results to the user.
		System.out.println("Total amount paid for the stock: $" + totalAmountPaid);
		System.out.println("Commission paid at your purchase: $" + commissionAtPurchase);
		System.out.println("Total amount that the stock was sold for: $" + totalAmountSoldFor);
		System.out.println("Commission paid when the stock was sold: $" + commissionWhenSold);
		System.out.println();	// Spacing
		System.out.println("TOTAL PROFIT: $" + totalProfit);
		
		// Close the scanner
		keyboard.close();
	}

}
