
/**
 * This class sets up a Coin object in the driver.
 * @author Benjamin Costello
 */

import java.util.Random;

public class Coin 
{
	// Fields
    private SIDES sideUp;
    
   /**
    * A constructor
    * @param s the side of the coin
    */
    public Coin(SIDES s)
    {
    	sideUp = s;
    }
    
    /**
     * Flips the coin and sets a random number/side the coin lands on.
     * @return the coin side
     */
	public SIDES toss()
    {
    	Random rnd = new Random();
    	
    	if (rnd.nextBoolean())
    		return sideUp = SIDES.HEADS;
    	else
    		return sideUp = SIDES.TAILS;
    }
}
