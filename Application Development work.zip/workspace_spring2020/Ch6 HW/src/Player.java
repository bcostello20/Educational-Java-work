
/**
 * This class sets up a player object in the driver.
 * @author Benjamin Costello
 *
 */

public class Player 
{
	private int player1Choice;	// Player 1's choice
	private int player2Choice;	// Player 2's choice
	private int player1Points;	// Player 1's points
	private int player2Points;	// Player 2's points
	private SIDES aSide = SIDES.HEADS;

	
	/**
	 * A constructor
	 * @param p1 player 1's choice
	 * @param p2 player 2's choice
	 */
	public Player(int p1, int p2)
	{
		player1Choice = p1;
		player2Choice = p2;
		player1Points = 0;
		player2Points = 0;
	}
	
	/**
	 * Copy constructor for Player
	 * @param other a copy of Player object
	 */
	public Player(Player other)
	{
		player1Choice = other.player1Choice;
		player2Choice = other.player2Choice;
		player1Points = other.player1Points;
		player2Points = other.player2Points;
		aSide = other.aSide;
	}
	
	/**
	 * Checks which player guessed the correct coin side and awards that player a point and takes a point
	 * from the player who guessed incorrectly.
	 */
	public void awardPoints(Player otherPoints) // Using copy constructor
	{
		Coin c = new Coin(aSide);
		
		if (otherPoints.player1Choice == c.toss().ordinal())
		{
			otherPoints.player1Points++;
			otherPoints.player2Points--;
			System.out.println("Player 1 gained a point!");
			System.out.println("Player 2 lost a point.");
		}
		else if (otherPoints.player2Choice == c.toss().ordinal())
		{
			otherPoints.player1Points--;
			otherPoints.player2Points++;
			System.out.println("Player 1 lost a point.");
			System.out.println("Player 2 gained a point!");
		}
	}
	
	// Get methods - These get the field values
	
	/**
	 * Gets the points for player 1
	 * @return player 1's points
	 */
	public int getPlayer1Points()
	{
		return player1Points;
	}
	
	/**
	 * Gets the points for player 2
	 * @return player 2's points
	 */
	public int getPlayer2Points()
	{
		return player2Points;
	}
}
