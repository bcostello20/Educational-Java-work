
/**
 * Driver.java
 * This driver runs the coin flip game and awards player points and decides a winner based on which player reaches 5 points first.
 * @author Benjamin Costello
 */

import java.util.Scanner;

public class Driver 
{
    private static int player1;
    private static int player2;
	
	public static void main(String[] args) 
	{
	    // Create Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		// Game instructions for console
		System.out.println("COIN FLIP GAME INSTRUCTIONS");
		System.out.println("A coin will be flipped. Each player will guess what side the coin will land on until a player reaches 5 points.");
		System.out.println("The players must pick between HEADS(0) or TAILS(1).\n");
		
		// Ask Player 1 and Player 2 for their guesses
		System.out.println("Player 1 guess: ");
		player1 = keyboard.nextInt();
		
		System.out.println("Player 2 guess: ");
		player2 = keyboard.nextInt();
		
		System.out.println();
		
		// Create a Player object
		Player players = new Player(player1, player2);
		
		// Print who guessed what side
		if (player1 == 0)
			System.out.println("Player 1: HEADS, Player 2: TAILS");
		else
			System.out.println("Player 1: TAILS, Player 2: HEADS");
		
		// Award points based on player guesses
		players.awardPoints(players);
		
		// Award players their points based on their choices until one reaches 5 points
		while (players.getPlayer1Points() < 5 || players.getPlayer2Points() < 5)
		{
			// Ask Player 1 and Player 2 for their guesses again
			System.out.println("\nPlayer 1 guess: ");
			player1 = keyboard.nextInt();
			
			System.out.println("Player 2 guess: ");
			player2 = keyboard.nextInt();
			
			// Print who guessed what side again
			if (player1 == 0)
				System.out.println("Player 1: HEADS, Player 2: TAILS");
			else
				System.out.println("Player 1: TAILS, Player 2: HEADS");
			
			// Continue to award points based on player guesses
			players.awardPoints(players);
			
			// Check if a player has reached 5 points and if so, declare that player the winner
			if (players.getPlayer1Points() == 5)
			{
				System.out.println("\nPlayer 1 reached 5 points and is the winner!");
				break;
			}
			else if (players.getPlayer2Points() == 5)
			{
				System.out.println("\nPlayer 2 reached 5 points and is the winner!");
				break;
			}	
		}
		
		// Close the Scanner
	    keyboard.close();
	}

}
