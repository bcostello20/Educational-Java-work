
public enum SIDES 
{
    HEADS, TAILS;
}
