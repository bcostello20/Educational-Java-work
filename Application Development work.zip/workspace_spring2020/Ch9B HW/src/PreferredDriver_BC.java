/**
 * The PreferredDriver file is the main program which sets preferred customers
 * using the non-default and default constructors. It also lets the customer know
 * what discount they get if any.
 * @author Benjamin Costello
 *
 */

public class PreferredDriver_BC 
{

	public static void main(String[] args) 
	{
		// Using non-default constructor
		PreferredCustomer_BC pc1 = new PreferredCustomer_BC("Benjamin Costello", "257 Milkweed Drive", "610-844-4896", "BC1-A06", 1205);
		
		// Display first preferred customer
		System.out.println("The first preferrred customer: \n" + pc1);
		
		// Using default constructor
		PreferredCustomer_BC pc2 = new PreferredCustomer_BC();
		pc2.setName("John Adams");
		pc2.setAddress("520 Chestnut Street");
		pc2.setPhone("No phone number exists");
		pc2.setCustomerNumber("JA1-A07");
		pc2.setPurchaseAmount(2070);
		
		System.out.println(); // Spacing
		
		// Display second preferred customer
		System.out.println("The second preferred customer: \n" + pc2);
	}

}
