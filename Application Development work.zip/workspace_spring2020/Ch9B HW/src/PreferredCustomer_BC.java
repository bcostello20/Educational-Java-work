/**
 * The PreferredCustomer class stores a customer's purchase amount and gives them a discount
 * based on how much they have spent at the store.
 * @author Benjamin Costello
 *
 */

public class PreferredCustomer_BC extends Customer_BC
{
	// Member fields
	private double purchaseAmount; // The amount of the customer's purchase
	public static final double DISCOUNT5 = 0.05; // Discount of 5%
	public static final double DISCOUNT6 = 0.06; // Discount of 6%
	public static final double DISCOUNT7 = 0.07; // Discount of 7%
	public static final double DISCOUNT10 = 0.10; // Discount of 10%
	
	/**
	 * Constructor
	 * Initializes fields with default values
	 */
	public PreferredCustomer_BC()
	{
		super();
		this.setName("No name provided");
		this.setAddress("No address provided");
		this.setPhone("No phone provided");
		this.setCustomerNumber("No customer number provided");
		this.purchaseAmount = 0.0;
	}
	
	/**
	 * Constructor
	 * Initializes fields with argument values
	 */
	public PreferredCustomer_BC(String n, String a, String p, String custNum, double purchaseAmount)
	{
		super();
		this.setName(n);
		this.setAddress(a);
		this.setPhone(p);
		this.setCustomerNumber(custNum);
		this.purchaseAmount = purchaseAmount;
	}
	
	/**
	 * The setPurchaseAmount method sets the customer's purchase amount.
	 * @param pAmount The customer's purchase amount.
	 */
	public void setPurchaseAmount(double pAmount)
	{
		this.purchaseAmount = pAmount;
	}
	
	/**
	 * The getPurchaseAmount method gets the customer's purchase amount.
	 * @return The customer's purchase amount.
	 */
	public double getPurchaseAmount()
	{
		return purchaseAmount;
	}
	
	/**
	 * toString method
	 * @return A reference to a String representation of the object.
	 */
	public String toString()
	{
		String str = super.toString();
		
		String s = "";
		
		if (purchaseAmount >= 500 && purchaseAmount < 1000.0)
			s = "You get a " + DISCOUNT5 + "% discount on all future purchases.";
		else if (purchaseAmount >= 1000.0 && purchaseAmount < 1500.0)
			s = "You get a " + DISCOUNT6 + "% discount on all future purchases.";
		else if (purchaseAmount >= 1500.0 && purchaseAmount < 2000.0)
			s = "You get a " + DISCOUNT7 + "% discount on all future purchases.";
		else if (purchaseAmount >= 2000.0)
			s = "You get a " + DISCOUNT10 + "% discount on all future purchases.";
		
		str+= "\nPurchase amount: " + purchaseAmount + "\n" + s;
		
		return str;
	}
}
