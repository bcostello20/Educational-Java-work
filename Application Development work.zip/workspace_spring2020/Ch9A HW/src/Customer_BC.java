/**
 * The Customer class stores information about a customer.
 * @author Benjamin Costello
 *
 */

public class Customer_BC extends Person_BC
{
	private String customerNumber; // The customer's number
	private boolean mailingList = true; // Does the customer want to be on the mailing address? Default of yes (true).
	
	/**
	 * Constructor
	 * Initializes fields with default values
	 */
	public Customer_BC()
	{
		super();
		this.customerNumber = "";
		this.mailingList = true;
	}
	
	/**
	 * Constructor
	 * Initializes fields with argument values
	 */
	public Customer_BC(String n, String a, String p, String customerNumber, boolean mailingList)
	{
		super();
		this.setName(n);
		this.setAddress(a);
		this.setPhone(p);
		this.customerNumber = customerNumber;
		this.mailingList = mailingList;
	}
	
	/**
	 * The setCustomerNumber method sets a customer's number.
	 * @param num The customer's number.
	 */
	public void setCustomerNumber(String num)
	{
		this.customerNumber = num;
	}
	
	/**
	 * The getCustomerNumber method gets the customer's number.
	 * @return The customer's number.
	 */
	public String getCustomerNumber()
	{
		return customerNumber;
	}
	
	/**
	 * The setMailingList method sets a customer's mailing list choice.
	 * @param mList The mailing list choice.
	 */
	public void setMailingList(boolean mList)
	{
		this.mailingList = mList;
	}
	
	/**
	 * The getMailingList method gets a customer's mailing list choice.
	 * @return The mailing list choice.
	 */
	public boolean getMailingList()
	{
		return mailingList;
	}
	
	/**
	 * toString method
	 * @return A reference to a String representation of the object.
	 */
	public String toString()
	{
		String str = super.toString();
		
		String s = "";
		
		if (mailingList)
			s = "You are on the mailing list.";
		else
			s = "You are not on the mailing list.";
		
		str+= "\nCustomer Number: " + customerNumber + "\n" + s;
		
		return str;
	}
}
