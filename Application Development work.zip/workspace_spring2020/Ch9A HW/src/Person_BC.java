
/**
 * Chapter 9A
 * The Person class stores basic information about a person.
 * @author Benjamin Costello
 */

public class Person_BC
{
   private String name;       // The person's name
   private String address;    // The person's address
   private String phone;      // The person's phone number

   /**
    * Constructor
    * Initializes fields with default values
    */

   public Person_BC()
   {
      name = "";
      address = "";
      phone = "";
   }

   /**
    * Constructor
    * Initializes fields with argument values
    */

   public Person_BC(String n, String a, String p)
   {
      name = n;
      address = a;
      phone = p;
   }

   /**
    * setName method
    */

   public void setName(String n)
   {
      name = n;
   }

   /**
    * setAddress method
    */

   public void setAddress(String a)
   {
      address = a;
   }

   /**
    * setPhone method
    */

   public void setPhone(String p)
   {
      phone = p;
   }

   /**
    * getName method
    */

   public String getName()
   {
      return name;
   }

   /**
    * getAddress method
    */

   public String getAddress()
   {
      return address;
   }

   /**
    * getPhone method
    */

   public String getPhone()
   {
      return phone;
   }
   
   /**
    * toString method
    * @return A reference to a String representation of the object.
    */
   public String toString()
   {
	   String str = "Name: " + name + "\nAddress: " + address + "\nPhone Number: " + phone;
	   
	   return str;
   }
}
