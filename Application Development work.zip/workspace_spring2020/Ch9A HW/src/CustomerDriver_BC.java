
/**
 * The CustomerDriver_BC file initializes a customer "jenny" with her information passed into the Customer_BC class.
 * It also asks the customer whether she wants to stay on the mailing list or be removed.
 * @author Benjamin Costello
 */

import java.util.Scanner;

public class CustomerDriver_BC extends Customer_BC
{

	public static void main(String[] args) 
	{
		// Create the jenny Customer_BC object
		Customer_BC jenny = new Customer_BC("Jenny Jenny", "123 Main Street", "555-867-5209", "147-A049", true);
		
		// Print the object
		System.out.println(jenny);
		System.out.println(); // For spacing
		
		// Create the Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		// Ask the customer if they want to remain on the mailing address
		System.out.println("Do you still want to be on the mailing address? (Yes/No): ");
		
		String answer = keyboard.nextLine();
		
		if (answer.equalsIgnoreCase("Yes"))
			jenny.setMailingList(true);
		else if (answer.equalsIgnoreCase("No"))
			jenny.setMailingList(false);
		
		if (jenny.getMailingList())
			System.out.println("\nMailing list forwards will continue.\n");
		else
			System.out.println("\nMailing list information will discontinue.\n");
			
		
		// Close the Scanner object
		keyboard.close();
		
		quickieDemo(jenny); //The method expects a Person object. We can pass jenny to this method
		 //because Jenny is both a Customer and a Person, thanks to inheritance.
		 //Question: Which toString will the method call on Jenny?
		 //The Person-level toString or the Customer-level toString?
		 //YOUR ANSWER: Customer-level toString
	}
	
	//method to print a Person object
	public static void quickieDemo(Person_BC p)
	{
		//calls the toString method on the passed in Person
		System.out.println("In Demo Method: " + p.toString());
	}


}
