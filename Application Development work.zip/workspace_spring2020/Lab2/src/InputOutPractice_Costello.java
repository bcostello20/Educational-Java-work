/**
 * This program focuses on several tasks involved with Chapter 2 Lab - Java Fundamentals.
 * Benjamin Costello
 * 1/21/2020
 */

import java.util.Scanner;
import javax.swing.JOptionPane;

public class InputOutPractice_Costello {

	public static void main(String[] args) 
	{
		/*
		 * Task #1 Using The Scanner Class For User Input
		 */
		
		// Create the Scanner object
		Scanner keyboard = new Scanner(System.in);
		
		// Variables
		String firstName;	// The user's first name
		String midName;	// The user's middle name
		String lastName;	// The user's last name
		String fullName;	// The user's full name
		String initials;	// The user's initials
		int age;	// The user's age
		String position;	// The user's desired position they are applying for
		double radius;	// The radius of a sphere entered by the user
		double volume;	// Using the volume formula, takes the user's radius and finds the volume of that sphere
		
		System.out.println("Enter first name: ");
		firstName = keyboard.nextLine();
		
		System.out.println("Enter middle name: ");
		midName = keyboard.nextLine();
		
		System.out.println("Enter last name: ");
		lastName = keyboard.nextLine();
		
		fullName = firstName + " " + midName + " " + lastName;
		
		// Get the first letter of the user's first, middle, and last name to use as their initials
		char letter1 = firstName.charAt(0);
		char letter2 = midName.charAt(0);
		char letter3 = lastName.charAt(0);
		initials = "" + letter1 + letter2 + letter3;
		
		System.out.println("Enter age: ");
		age = keyboard.nextInt();
		keyboard.nextLine();	// Used to skip the blank spot in the buffer and go to the job that is entered next (below)
		
		System.out.println("Enter position applying for: ");
		position = keyboard.nextLine();
		
		System.out.println("*************************************");
		System.out.println();
		
		System.out.print("The applicant information is below.\n" + "\tFull Name: " 
		+ fullName.toUpperCase() + "\n\tInitials: " 
		+ initials.toUpperCase() + "\n\tAge: " 
		+ age + "\n\tDesired Position: " 
		+ position.toUpperCase());
		
		/*
		 * Task #2 Using Dialog Boxes For User Input
		 */
		
		String cityOfBirth = JOptionPane.showInputDialog("Enter city of birth.");	// Gets the user's city of birth
		String stateOfBirth = JOptionPane.showInputDialog("Enter state of birth.");	// Gets the user's state of birth
		
		String birthInfo = cityOfBirth + ", " + stateOfBirth;	// Combines the user's city and state to display them in proper format
		
		JOptionPane.showMessageDialog(null, "Applicant was born in: " + birthInfo);
		
		/*
		 * Task #3 Using Predefined Math Functions
		 */
		
		System.out.println("\nEnter the radius of a sphere: ");
		radius = keyboard.nextDouble();
		
		// Close the scanner
		keyboard.close();
		
		volume = 1.33 * Math.PI * Math.pow(radius, 3);
		
		JOptionPane.showMessageDialog(null, "The volume of the sphere is: " + volume);
		
		System.exit(0);
	}

}
